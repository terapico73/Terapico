package ncs.test8;

public class Sales extends Employee implements Bonus {
	
	// 생성자
	public Sales() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Sales(String name, int number, String department, int salary) {
		super(name, number, department, salary);
		// TODO Auto-generated constructor stub
	}
	
	// 	세금을 계산해서 리턴한다. 
	public double tax() {
		// salary에 13% 적용한다.
		return super.getSalary() * 0.13;
	}

	// 인센티브 지급	
	public void incentive(int pay) {
		// 인센티브 지급, pay의 120% 가 기존 salary에 더해진다.
		// System.out.println("인센티브 : " + (super.getSalary() + (pay * 1.2)) );		
		super.setSalary( (int) (super.getSalary() + (pay * 1.2)));
	}

}
