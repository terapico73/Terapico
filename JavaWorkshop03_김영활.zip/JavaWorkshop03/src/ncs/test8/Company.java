package ncs.test8;

public class Company {

	// Abstract 클래스에서 상속받고 Interface를 구현한 두 개의 클래스를 구현하여 
	// 항목 5번의 실행결과가 나오도록 프로그램을 작성한다. 
	
	public static void main(String[] args) {
		
		Employee[] emp = new Employee[2]; 
		
		// 1번의 사용 데이터를 기반으로 객체를 생성하여 배열에 넣는다 . 
		emp[0] = new Secretary	("Hilery  ", 1, "secretary", 800);
		emp[1] = new Sales		("Clinten ", 2, "sales     ", 1200);
		
		// 모든 객체의 기본 정보를 출력한다 (for 문을 이용하여 출력한다.) 
		System.out.println("name  \tdepartment\tsalary");
		System.out.println("------------------------------------");
		
		for(int i =0 ; i < emp.length ; i++ ) {
			System.out.println(emp[i]);
		}
		
		// 모든 객체에 인센티브 100 씩 지급한 급여를 계산하고 다시 객체의 salary에 넣는다 . 
		System.out.println();
		System.out.println("인센티브 100 지급");

		// 다운캐스팅 - employees에서 자손 클래스를 통해 interface Bonus 의 incentive, tax 메소드 활용
	      for (int i = 0; i < emp.length; i++) {
	          
	    	  // 다운캐스팅 가능 확인 확인
	    	  if (emp[i] instanceof Secretary) {
	    		  // 다운캐스팅을 통한 데이터 전달 및 처리
	             ((Secretary) emp[i]).incentive(100);	
	             ((Secretary) emp[i]).tax();
	          }
	    	  
	    	  // 다운캐스팅 가능 확인	    	  
	          if (emp[i] instanceof Sales) {
	    		  // 다운캐스팅을 통한 데이터 전달 및 처리
	        	  ((Sales) emp[i]).incentive(100); 
	             ((Sales) emp[i]).tax();
	          }
	       }
		
		System.out.println("name  \tdepartment \tsalary \ttax");
		System.out.println("------------------------------------");
		// 모든 객체의 정보와 세금을 출력한다 (for 문을 이용하여 출력한다.)
		for(int i =0 ; i < emp.length ; i++ ) {
			System.out.println(emp[i]);
		}
	}

}
