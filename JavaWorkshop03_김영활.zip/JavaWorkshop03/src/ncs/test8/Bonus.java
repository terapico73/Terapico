package ncs.test8;

interface Bonus {
	public default void incentive(int pay) {
		// 인센티브 지급 -  Sales와 Secretary 에 따라 비율이 다름 
		// 자손에서 처리함
	}
}
