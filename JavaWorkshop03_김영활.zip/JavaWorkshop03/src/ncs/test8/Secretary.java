package ncs.test8;

public class Secretary extends Employee implements Bonus {	
	
	// 생성자
	public Secretary() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Secretary(String name, int number, String department, int salary) {
		super(name, number, department, salary);
		// TODO Auto-generated constructor stub
	}

	// 세금을 계산해서 리턴한다.	
	public double tax() {
		// salary에 10% 적용한다.
		return super.getSalary() * 0.1;
	}

	// 인센티브 지급	
	public void incentive(int pay) {
		// 인센티브 지급, pay 의 80%가	기존 salary에 더해진다
		// System.out.println("인센티브 : " + (super.getSalary() + (pay * 0.8)) );		
		super.setSalary( (int) (super.getSalary() + (pay * 0.8)));		
	}
	
}
