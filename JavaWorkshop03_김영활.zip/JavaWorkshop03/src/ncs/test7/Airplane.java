package ncs.test7;

public class Airplane extends Plane {
		
	// 생성자
	public Airplane() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Airplane(String planeName, int fuelSize) {
		super(planeName, fuelSize);
		// TODO Auto-generated constructor stub
	}

	// + flight(distance:int):void // 운항 
	@Override	
	public void flight(int distance) {
		// 일정 거리 만큼 운항, 연료 감소10 운항시 연료 30 감소
		// System.out.println("운항 : "+ (super.getFuelSize() - (distance / 10) * 30)) ;
		super.setFuelSize((super.getFuelSize() - (distance / 10) * 30)); 	
		
	}
	

}
