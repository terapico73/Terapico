package ncs.test7;

public class Cargoplane extends Plane {

	// 생성자
	public Cargoplane() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cargoplane(String planeName, int fuelSize) {
		super(planeName, fuelSize);
		// TODO Auto-generated constructor stub
	}

	// + flight(distance:int):void // 운항
	@Override
	public void flight(int distance) {

		// 일정 거리 만큼 운항, 연료 감소10 운항시 연료 50 감소
		// System.out.println("운항 : "+ (super.getFuelSize() - (distance / 10) * 30)) ;
		super.setFuelSize((super.getFuelSize() - (distance / 10) * 50)); 		
		
	}

}
