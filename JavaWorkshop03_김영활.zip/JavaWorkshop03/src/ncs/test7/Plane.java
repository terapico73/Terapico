package ncs.test7;

// Abstract Class
abstract class Plane {

	// 필드
	private String planeName;
	private int fuelSize;
	
	// 생성자
	public Plane() {}
			
	public Plane(String planeName, int fuelSize) {
		super();
		this.planeName = planeName;
		this.fuelSize = fuelSize;
	}			

	// getter & setter
	public int getFuelSize() {
		return fuelSize;
	}

	public void setFuelSize(int fuelSize) {
		this.fuelSize = fuelSize;
	}

	// + refuel(fuel:int):void  //주유
	public void refuel(int fuel) {
		 //주유 - 일정 양의 연료 주입,  기존 연료가 증가됨
		this.setFuelSize((this.getFuelSize() + fuel)); 
	}

	// 출력
	@Override
	public String toString() {
		return planeName + "\t\t" + fuelSize;
	}

	// 운항(Abstract method)	- 일정 거리만큼 운항, 연료 감소됨
	// 추상 메소드로 하위 객체에서 반드시 구현해야 함	
	// + flight(distance:int):void  //운항(Abstract method) 
	public abstract void flight(int distance);
	
}
