package ncs.test7;

public class PlaneTest {

	// Abstract 클래스에서 상속받은 두 개의 클래스를 구현하여 
	// 아래 5번 항목의 실행 결과가 나오도록 프로그램을 작성한다. 
	
	public static void main(String[] args) {
		
		 // Airplane 과 Cargoplane 객체 생성 
		Plane[] plan = new Plane[2];
		
		plan[0] = new Airplane("L747", 1000);
		plan[1] = new Cargoplane("C40", 1000);
		
		// 생성된 객체의 정보 출력 
		System.out.println("Plane\t\tfuelSize");
		for(Plane p : plan) {
			System.out.println(p);
		}
		System.out.println();
		
		// Airplane 과 Cargoplane 객체에 100 씩 운항 
		System.out.println("100 운항");		
		plan[0].flight(100);
		plan[1].flight(100);		
		
		System.out.println("Plane\t\tfuelSize");
		 // 100 운항 후 객체 정보 출력 
		for(Plane p : plan) {
			System.out.println(p);
		}
		System.out.println();
		
		 // Airplane 과 Cargoplane 객체에 200 씩 주유
		System.out.println("200 주유");
		plan[0].refuel(200);
		plan[1].refuel(200);
		
		 // 200 주유 후 객체 정보 출력
		for(Plane p : plan) {
			System.out.println(p);
		}
	}

}
