package ncs.test5;

public class Human {
	
	// 필드
	private String name;
	private int intage;
	private int intheight;
	private int weight;
	
	// 생성자
	public Human() {}
	
	public Human(String name, int intage, int intheight, int weight) {
		super();
		this.name = name;
		this.intage = intage;
		this.intheight = intheight;
		this.weight = weight;
	}	
	
	// getter - 자손에서 출력을 위해 요청시 필요
	public String getName() {
		return name;
	}

	public int getIntage() {
		return intage;
	}
	public int getIntheight() {
		return intheight;
	}

	public int getWeight() {
		return weight;
	}
	
	// setter 는 필요없음

	// 출력은 - 자손에서 실시
}
