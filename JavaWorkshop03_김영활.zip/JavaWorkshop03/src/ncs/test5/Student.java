package ncs.test5;

public class Student extends Human {
	
	// 필드
	private String number;
	private String major;
	
	// 생성자
	public Student() {}

	public Student(String name, int intage, int intheight, int weight, String number, String major) {
		super(name, intage, intheight, weight);
		this.number = number;
		this.major = major;
	}

	// 출력 +toString():String >> 부모필드활용
	@Override
	public String toString() {
		// 홍길순 25 171 81 201401 영어영문학
		return  super.getName() + "\t" 
				+ super.getIntage() + "\t" 
				+ super.getIntheight() + "\t" 
				+ super.getWeight() + "\t"
				+ number + "\t" + major ;
	}
	

	
}
