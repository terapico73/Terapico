package ncs.test9;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Inventory {
	
	// 필드
	private String productName; 	//상품명
	private Date putDate; 				//입고일
	private Date getDate; 				//출고일
	private int putAmount; 			//입고수량
	private int getAmount; 			//출고수량
	private int inventoryAmount; 	//재고수량
	
	// 생성자
	public Inventory() {}
	
	// Inventory(productName:String, putDate:Date, putAmount:int)	
	public Inventory(String productName, Date putDate, int putAmount) {
		// 매개변수 있는 생성자
		// 상품명, 입고날짜, 입고수량 초기화
		// 재고량은 입고수량으로 지정한다
		this.productName = productName;
		this.putDate = putDate;
		this.putAmount = putAmount;
		this.inventoryAmount = putAmount;
	}

	
	// 출고수량 getter
	public int getGetAmount(int getAmount) {
		return getAmount;
	}	

	// 출고수량 setter - 출고 날짜를 지정한다. 
	public void setGetDate(Date getDate) {
		this.getDate = getDate;
	}	
	
	// 재고수량 getter
	private int getInventoryAmount() {
		return inventoryAmount;
	}
	
	


	// 재고수량 setter
	public void setInventoryAmount(int inventoryAmount) {
		this.inventoryAmount = inventoryAmount;
	}	

	// 출고수량 setter  - 출고수량을 지정한 다음, 재고수량을 지정한다. (입고수량 – 출고수량)
	public void setGetAmount(int getAmount) {
		
		// System.out.println(this.productName +" 입고수량 : "+  putAmount  +", 재고수량 : "+ inventoryAmount +", 출고 수량 : "+getAmount);
		
		// 단, 출고수량이 입고수량보다 많을 경우에는 AmountNotEnough 예외를 발생시킨다.  
		if (getAmount > putAmount) {
			System.out.println(productName +" 현재 재고가 부족합니다. 재고수량 확인하시기 바랍니다.");
		} else {			
			// 출고 수량을 지정
			this.getAmount = getAmount;
			
			// 재고수량을 지정. (입고수량 – 출고수량)
			this.setInventoryAmount(putAmount - getAmount); 

		}
	}

	// Object 의 toString() 오버라이드	Inventory 객체의 모든 필드 정보 문자열 리턴한다.
	// 단, 날짜 데이터는 SimpleDateFormat 을 적용한다. 	
	@Override
	public String toString() {

		// 날짜 데이터형식 선언 - SimpleDateFormat 적용
		SimpleDateFormat printPutAmountDate = new SimpleDateFormat("yyyy년 M월 dd일 입고, ");
		SimpleDateFormat printGetAmountDate = new SimpleDateFormat("yyyy년 M월 dd일 출고, ");

		String result = null;

		//System.out.println(this.getDate);	
		if (getDate == null ) {
			// 출고전
			result = productName + "\t"	// 제품명
						+ printPutAmountDate.format(putDate) + putAmount + "개, "+ "\t"	 // 입고일 & 입고 수량
						+ null + ", " + getAmount + "개, " + "\t"				// 출고일 & 출고 수량
						+ "재고 " + this.getInventoryAmount() + "개";		// 재고수량
		} else {
			// 출고후
			result = productName + "\t"	  // 제품명
					+ printPutAmountDate.format(putDate) + putAmount + "개, "+ "\t"  // 입고일 & 입고 수량
					+ printGetAmountDate.format(getDate) + getAmount + "개, "+ "\t"  // 출고일 & 출고 수량
					+ "재고 " + this.getInventoryAmount()	+ "개"; 	// 재고수량
		} 

		return result;
	}



}
