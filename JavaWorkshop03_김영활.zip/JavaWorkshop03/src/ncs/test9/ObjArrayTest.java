package ncs.test9;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ObjArrayTest {

	// 객체배열을 사용하여 상품재고 정보를 저장하고 출력되게 한다.   
	// 출력시 날짜 데이터에 대해서는 SimpleDateFormat 을 사용하여 출력 처리한다. 
	
	public static void main(String[] args) {
		
		Object[] array = new Object[3];
		
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy. MM. dd");
		 // System.out.println(dateFormat.parse("2016. 03. 15"));  date 타입으로 변경됨.
		 
		// 제시된 사용데이터를 사용하여 저장 처리 한다.
		// try ~  catch (ParseException e)  는 dateFormat.parse 를 사용하면서 이클립스가 자동 처리해준 소스임.
		try {
			array[0] = new Inventory("삼성 갤럭시S7, ", dateFormat.parse("2016. 03. 15"), 30);
			array[1] = new Inventory("LG G5,             ", dateFormat.parse("2016. 02. 25"), 20);
			array[2] = new Inventory("애플 아이패드, ", dateFormat.parse("2016. 01. 23"), 15);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
		}		
		
		// 1. 배열에 기록된 정보를 연속 출력한다. For each() 사용한다.
		// 출고전
        for (Object item : array) {
            System.out.println( item.toString() );
        }
		System.out.println(); 
        
		// 2. 배열에 기록된 정보를 Inventory[] 로 변환한 다음      
		Inventory[] inventoryArray = new Inventory[array.length];
		for (int i = 0; i < array.length; i++) {
		    inventoryArray[i] = (Inventory) array[i];
		}
		
		// Inventory 배열에 저장된 정보
		/*
        for (Inventory item : inventoryArray) {
            System.out.println( item.toString() );
        }
		System.out.println(); 
		*/
		
		// 3. 출고 날짜를 오늘 날짜로, 출고 수량은 모두 10개로 지정한다.
        System.out.println("출고 수량 10 적용시 ----------------------------------------------------------");
        for (Inventory item : inventoryArray) {
        	item.setGetDate(new Date());	// 출고 날짜를 오늘 날짜
        	item.setGetAmount(10);			// 출고 수량은 모두 10개
           
    	   System.out.println(((Inventory) item).toString());
        }
		System.out.println();
		
		
		// (추가) 출고 날짜를 오늘 날짜로, 출고 수량은 모두 20개로 지정한다.
		System.out.println("출고수량 부족시 - 출고 수량 25 추가 적용시 --------------------------------");
        for (Inventory item : inventoryArray) {
        	item.setGetDate(new Date());	// 출고 날짜를 오늘 날짜
        	item.setGetAmount(25);			// 출고 수량은 모두 25개
           
    	   // System.out.println(((Inventory) el).toString());
        }        
		System.out.println(); 
	}

}
