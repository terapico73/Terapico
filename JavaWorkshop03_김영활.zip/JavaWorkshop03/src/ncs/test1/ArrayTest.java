package ncs.test1;

public class ArrayTest {

	// 2차원 배열에 들어 있는 데이터들의 합계와 평균을 구한다
	
	public static void main(String[] args) {
		
		// 제시된 배열
		int [][] array = {{12, 41, 36, 56, 21}, {82, 10, 12, 61, 45}, {14, 16, 18, 78, 65}, {45, 26, 72, 23, 34}};
		
		// 합계 초기화
		double sum = 0;
		
		// 배열값 가져와서 합계구하기
		for(int i = 0; i < array.length ; i++) {
			for(int j = 0; j < array[i].length ; j++) {			
				sum += array[i][j];
				// System.out.println( array[i][j] );
			}
		}
		
		// 소수점 자리수 처리
		String str = String.format("%.2f", sum);
		
		// 출력 결과는 다음과 같다. 소수점 아래 둘째자리까지 출력되게 한다.
		// 합계와 평균 값은 double로 처리한다.
		System.out.println("합계 : "+ str);
		System.out.println("평균 : "+ (double) sum/ (array.length * array[0].length) );
	}

}
