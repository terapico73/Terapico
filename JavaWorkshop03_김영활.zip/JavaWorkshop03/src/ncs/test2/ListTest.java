package ncs.test2;

import java.util.Random;

public class ListTest {

	// 정수 배열에 값들을 저장하고, 내림차순 정렬된 결과를 출력되게 하시오
	// main 함수 안에서 배열 생성처리와 값 기록 메소드, 정렬 메소드, 출력 메소드를 차례대로 실행시킨다.	
	public static void main(String[] args) {
		
		// 배열 생성		
		int[] array = new int[10];

		// init() 메소드를 호출한다.
		ListTest ref = new ListTest();
		ref.init(array);		
		
		// 정렬전 display() 메소드를 호출한다
		System.out.print("정렬전 : ");		
		ref.display(array);
		System.out.println();
		
		// 정렬 : sort() 메소드를 호출한다.
		ref.sort(array);	

		
		// 정렬후 display() 메소드를 호출한다.
		System.out.print("정렬후 : ");		
		ref.display(array);

	}

	// 랜덤값 기록
	public void init(int[] arr) {
		// Java.util.Random 을 사용하여 전달받은 배열에 1부터 100사이의 정수를 기록한다.
		Random rd = new Random();
		for(int i = 0; i < arr.length ; i ++) {
			arr[i] = rd.nextInt(100);
			//System.out.print( arr[i] + " ");
		}
		return;
	}

	// 출력	
	public void display(int[] arr) {
		// 배열을 받아서 출력시킨다.		
		for(int i = 0; i < arr.length ; i ++) {
			System.out.print("\t" + arr[i]);
		}		
	}	
	
	// 스왑을 위해 값의 차이를 이용
	public int compare(int d1, int d2) {
		// 2개의 정수를 전달받아, 빼기한 결과를 리턴한다.	
	    return d1 - d2;
	}		
	
	// 정렬
	public void sort(int[] arr) {
	      for (int i = 0; i < arr.length - 1; i++) {
	          for (int j = i + 1; j < arr.length; j++) {	            
	        	 
	        	  //비교 : 결과가 음수면 자리 바꿈 - 스왑목적
	        	  if (compare(arr[i], arr[j]) < 0) {
	                int temp = arr[j];
	                arr[j] = arr[i];
	                arr[i] = temp;
	             }
	        	  
	          }
	       }
		return;
	}

}
