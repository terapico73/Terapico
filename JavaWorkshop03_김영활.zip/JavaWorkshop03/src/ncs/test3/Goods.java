package ncs.test3;

public class Goods {
	
	// 필드
	private String name;
	private int price;
	private int quantity;
	
	// 생성자
	public Goods() {}
	
	public Goods(String name, int price, int quantity) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;		
	}

	// getter & setter
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	// 출력
	@Override
	public String toString() {
		return "Goods [name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
	}
	
}
