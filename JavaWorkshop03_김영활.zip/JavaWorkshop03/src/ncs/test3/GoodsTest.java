package ncs.test3;

import java.util.Scanner;

public class GoodsTest {

	// main 함수 안에서 Goods 객체 초기값을 키보드로 입력받아 초기화 생성하고, 
	// 필드값을 초회해서 계산하고 출력한다.	
	
	public static void main(String[] args) {
		
		// Scanner 에 대해 선언한다.
		Scanner sc = new Scanner(System.in);
		
		 // 입력 처리하고 출력처리 한다.
		System.out.println("다음 항목의 값을 입력하시오");
		System.out.print("상품명 : ");
		String name = sc.nextLine();		
		
		System.out.print("가격 : ");
		int price = sc.nextInt();
		
		System.out.print("수량 : ");
		int  quantity = sc.nextInt();
		
		// 생성자 호출 - 클래스생성과 객체생성
		Goods goods = new Goods();
		goods = new Goods(name, price, quantity);

		//총 구매가격을 계산하여 출력한다.
		System.out.println();
		System.out.println("입력된 결과는 다음과 같습니다.");	
		System.out.println(goods.getName() +", " + goods.getPrice()  +"원, "+ goods.getQuantity() +"개");
		System.out.println("총 구매 가격 : " + goods.getPrice() * goods.getQuantity() + "원");	

		sc.close();		
		
	}

}
