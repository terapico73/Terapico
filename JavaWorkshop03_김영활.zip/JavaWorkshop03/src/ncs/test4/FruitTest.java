package ncs.test4;

public class FruitTest {

	// 객체배열을 Fruit[] 에 객체 정보들을 기록하고 Fruit[]의 값들을 화면에 출력 처리한다.
	
	public static void main(String[] args) {
		
		// initFruit() 메소드를 호출하여 Fruit[]을 받는다.
		FruitTest ref = new FruitTest();		
		Fruit[] fruits = ref.initFruit(5);
		 
		// printFruit() 메소드를 호출한다.
		ref.printFruit(fruits);

	}
	
	public Fruit[] initFruit(int length) {
		// Fruit[] 배열을 생성하고, 명시된 초기값으로 객체 초기화 생성한다.
		Fruit[] fruits = new Fruit[length]; // Fruit[] 배열을 생성합니다.
		
		// 배열 레퍼런스를 리턴한다.
	    fruits[0] = new Fruit("apple", 1200, 3);
	    fruits[1] = new Fruit("banana", 2500, 2);
	    fruits[2] = new Fruit("grape", 4500, 5) ;
	    fruits[3] = new Fruit("orange", 800, 10);
	    fruits[4] = new Fruit("melon", 5000, 2);	    
	        
		return fruits; // 배열 레퍼런스를 반환합니다.
	}
	
	public void printFruit(Fruit[] fruits) {
		// 배열 레퍼런스를 사용하여 객체정보를 출력한다. 오버라이딩한	toString() 메소드 사용한다.	
		for (int i =0; i < fruits.length ; i++) {
			System.out.println((i+1)+ " = "+ fruits[i].toString());
		}
	}

}
