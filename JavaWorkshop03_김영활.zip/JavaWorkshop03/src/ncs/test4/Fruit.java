package ncs.test4;

public class Fruit {
	private String name;
	private int price;
	private int quantity;
	
	public Fruit() {}
	
	public Fruit(String name, int price, int quantity) {
		super();
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		// 1 = apple, 1200원, 3개
		return name + ", " + price + "원, " + quantity + "개";
	}

	
}
