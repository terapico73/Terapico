package io.silsub2;

import java.io.*;
import java.util.Scanner;

public class SungjukProcess {

	//- Field	- sc:Scanner	//초기화 객체 생성함
	private Scanner sc = new Scanner(System.in);
	
	//	- main() 메소드 포함	
	public static void main(String[] args) {
		//	1. 실행을 위한 객체 생성
		SungjukProcess ref = new SungjukProcess();
		
		//	2. 메소드 실행
		// 파일로 저장 : out, write
		ref.sungjukSave();
		System.out.println();
		
		// 파일에서 읽기 : in, read
		ref.scoreRead();
	}

	// - public void sungjukSave(){}
	private void sungjukSave(){	
		
		// 스트림생성
		// try ( FileWriter fw =  new FileWriter("score.dat") ) {			
		try ( DataOutputStream dout = new DataOutputStream( new FileOutputStream("score.dat") ) ) {
			while (true) {				
				// 1. 정수형으로국어, 영어, 수학 점수를 입력받아,
				System.out.print("국어 점수 : ");
				int korScore = sc.nextInt();
				System.out.print("영어 점수 : ");
				int engScore = sc.nextInt();
				System.out.print("수학 점수 : ");
				int mathScore = sc.nextInt();
				
				//	2. 총점(int), 평균(double)을 계산하고
				int total = korScore + engScore + mathScore;
				double avg = total / 3;					
			
				//	3. "score.dat" 파일에 국, 영, 수, 총점, 평균을 기록 저장함			
				// fw.write(korScore + ", " + engScore + ", " + mathScore + ", " + total + ", " + avg + "\n");
				// dout.writeUTF(korScore + ", " + engScore + ", " + mathScore + ", " + total + ", " + avg + "\n");
				
				dout.writeInt(korScore);
				dout.writeInt(engScore);
				dout.writeInt(mathScore);
				dout.writeInt(total);
				dout.writeDouble(avg);
				
				// 4. "계속 저장하시겠습니까? (y/n) : " 에서 'Y'이면 반복 실행함			
				System.out.println("계속 저장하시겠습니까? (y/n) : ");
				if (sc.next().toUpperCase().charAt(0) != 'Y') break;
			}
			
			//	5. 'N' 이면 반복 종료하고, "score.dat 에 저장 완료." 출력함			
			System.out.println("score.dat 에 저장 완료.");		
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	//	 - public void scoreRead(){}
	public void scoreRead(){
		
		int totalSum = 0;
		double totalAvg = 0;
		int count = 0;
		
		// try( FileReader fw =  new FileReader("score.dat")  ){
		try ( DataInputStream dIn = new DataInputStream( new FileInputStream("score.dat") ) ) {
			//	1. 파일에 기록된 정보를 국, 영, 수, 총점, 평균 순으로 읽어와서

			//	2. 변수에 저장하고 출력하고, 총점의 합, 평균의 합을 구하고
			//	    단, 평균은 소숫점 둘째자리까지만 출력되게 함	
			while(true){

				int korScore = dIn.readInt();
				int engScore = dIn.readInt();
				int mathScore = dIn.readInt();
				int total = dIn.readInt();
				double avg = dIn.readDouble();
				
				System.out.println(korScore +"\t"+ engScore +"\t"+  mathScore +"\t"+  total +"\t"+  avg );
				
				totalSum += total;
				totalAvg += avg;
				count++;
			} 			
			//	3. 전체 총점과 전체 평균을 읽어온 횟수로 나누어 
			//	   읽은 횟수와 전체총점, 전체 평균 화면 출력함
			//	   단, 전체 평균은 소숫점 둘째자리까지만 출력되게 함
			
			// 4. 읽기가 끝나면 "score.dat 파일 읽기 완료." 출력	
			
		}catch(EOFException e){
			//	3. 전체 총점과 전체 평균을 읽어온 횟수로 나누어 
			//	   읽은 횟수와 전체총점, 전체 평균 화면 출력함
			//	   단, 전체 평균은 소숫점 둘째자리까지만 출력되게 함
			System.out.println(count+"\t"+"\t"+ "\t"+  totalSum/count +"\t"+ String.format("%.2f",totalAvg/count) );
		
			// 4. 읽기가 끝나면 "score.dat 파일 읽기 완료." 출력
			System.out.println("score.dat 파일 읽기 완료...");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}			
	}
}