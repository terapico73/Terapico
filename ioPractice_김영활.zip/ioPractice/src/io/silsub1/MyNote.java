package io.silsub1;

import java.io.*;
import java.util.Scanner;

//  문자기반 스트림과 보조스트림으로 버퍼이용스트림 클래스를 사용하시오.

public class MyNote {
	// - Field : - sc:Scanner
	private Scanner sc = new Scanner(System.in);	//초기화 생성함

	// - Constructor : default	
	public MyNote() {}
	
	// - Method
	//	+ fileSave():void
	public void fileSave() {
		
		// 스트림 생성 
		BufferedWriter bw = null;
		
		try {
			//1. "파일에 저장할 내용을 입력하시오"  출력
			System.out.println("파일에 저장할 내용을 입력하시오");	

			//2. StringBuilder 를 사용하여 문자열을 반복해서 입력받아 추가함
			StringBuilder sb = new StringBuilder();
			
			//3. "exit" 입력되면 반복 종료함			
			String inputStr = null;
			while (  !(inputStr = sc.nextLine() ).equals("exit") ) {
				sb.append(inputStr + "\n");
			};

			// 4. "저장하시겠습니까? (y/n) : " 출력
			System.out.println("저장하시겠습니까? (y/n) : ");			
			
			//5. 입력값이 대소문자 상관없이 'Y' 이면, "저장할 파일명 : " 출력
			if ( sc.next().toUpperCase().charAt(0) == 'Y') {
				System.out.print("저장할 파일명 : ");
				
				//6. 파일명 입력받아
				String fileName = sc.next();
				
				// 해당 파일에 출력 기록함.
				bw = new BufferedWriter( new FileWriter( fileName ) ); 
				bw.write( sb.toString() );
					
				//7. "oooo.txt 파일에 성공적으로 저장하였습니다." 출력
				System.out.println(fileName + "파일에 성공적으로 저장하였습니다.");
			} 
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			//8. 스트림 반납하고 리턴함
			try {
				if (bw != null ) bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
			
		}
	}
	
	//	+ fileOpen():void
	public void fileOpen() {
		//1. "열기할 파일명 : " 출력하고, 파일명 입력받음
		System.out.print("열기할 파일명 : ");
		String fileName = sc.next();
		
		//2. 파일 입력 스트림 생성
		BufferedReader br = null;
		
		try {
			//3. 파일의 내용을 한 줄씩 읽어서 화면에 출력함			
			br = new BufferedReader( new  FileReader(fileName) );
			
			// 읽어들임, 출력
			String readStr = null;
			while( ( readStr = br.readLine()) != null ){
				System.out.print( readStr + "\n" );
			}
			System.out.println("출력완료 ");			
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			//4. 스트림 반납하고 리턴
			try {
				if (br != null )  br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	//	+ fileEdit():void
	public void fileEdit() {
		
		//1. "수정할 파일명 : " 출력하고, 파일명 입력받음
		System.out.print("수정할 파일명 : " );
		String fileName = sc.next();
		
		//2. 파일 입력 스트림 생성
		//3. 파일 출력 스트림 생성 : 단, 기존 내용 둔 상태로 생성할 것
		try ( BufferedReader br = new BufferedReader( new FileReader(fileName) ); 
					BufferedWriter bw = new BufferedWriter( new FileWriter(fileName, true) ); ) {
						
			//4. 파일의 내용을 읽어, StringBuilder 에 저장
			StringBuilder sb = new StringBuilder();

			String readStr;
			while ( (readStr = br.readLine()) != null ) {
			    sb.append(readStr +"\n");
			}
		    // System.out.println( "출력 : " + (StringBuilder) sb );						
			
			//5. "파일에 추가할 내용을 입력하시오." 출력하고, 추가할 내용 입력받음
			//6. 추가내용을 StringBuilder 에 추가함 : 반복
			//7. "exit" 입력하면 반복 종료함
		    System.out.println("파일에 추가할 내용을 입력하시오.");			

			// / 이전글이 중복 추가됨에 따라 인해 추가함
			StringBuilder sb1 = new StringBuilder();		    
		    
		    String appendStr = null;
			while (  !(appendStr = sc.nextLine()).equals("exit") ) {
				sb1.append(appendStr + "\n");
			};

			//8. "변경된 내용을 파일에 추가하시겠습니까? (y/n) : " 출력
			System.out.print("변경된 내용을 파일에 추가하시겠습니까? (y/n) : ");

			//9. 대소문자 상관없이 'Y'이면, 파일에 기록함			
			if ( sc.next().toUpperCase().charAt(0) == 'Y') {
				bw.write(sb1.toString());
				
				//10. "ooo.txt 파일의 내용이 변경되었습니다." 출력			
				System.out.println(fileName +" 파일의 내용이 변경되었습니다.");				
			}		 
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}  
	}		
}
