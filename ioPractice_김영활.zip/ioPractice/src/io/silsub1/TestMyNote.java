package io.silsub1;

import java.util.Scanner;

public class TestMyNote {

	public static void main(String[] args) {
		//main() 메소드 포함	
		
		//1. menu() 메소드 실행함
		menu();
		System.out.println("프로그램 종료!!!");
	}
	
	//2. public static void menu() 작성		
	public static void menu() {
	
		//* 구현 내용
		//MyNote 클래스 객체 생성함
		MyNote ref = new MyNote();
		
		//키보드 입력용 객체 생성함
		Scanner sc = new Scanner(System.in);	

		//아래 내용이 콘솔에 출력되게 함
		//입력된 번호에 따라, MyNote 의 메소드 실행시킴
		//메뉴 반복 실행
		do {
			System.out.println("\n******   MyNote  *******\n");
			System.out.println("1. 노트 새로 만들기");			// MyNote의 fileSave()
			System.out.println("2. 노트 열기");					// MyNote의 fileOpen()
			System.out.println("3. 노트 열어서 수정하기");	// MyNote의 fileEdit()
			System.out.println("4. 끝내기\n");						// main() 으로 리턴
			System.out.print("메뉴 선택 : ");
			int  num = sc.nextInt();
				
			switch(num){
				case 1 : ref.fileSave(); 	break;
				case 2 : ref.fileOpen(); break;
				case 3 : ref.fileEdit(); 	break;
				case 4 : 	return;
				default: 
					System.out.println("다른번호를 입력하세요. ");	
			}

		    
		} while(true);
		
	}
}
