package io.silsub3;

import java.io.*;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class BookManager {
	// * Field
	//~ sc:Scanner	//초기화 객체 생성함
	Scanner sc = new Scanner(System.in);	//초기화 객체 생성함	

	// * default 생성자
	public BookManager(){}
	
	
	//* Method
	// + fileSave():void
	public void fileSave(){	
		//	1. Book 객체 배열 선언, 5개 초기화함 - 샘플데이터 임의 작성	
		// public Book(String title, String author, int price, Calendar dates, double discountRate) {
		Book[] books = new Book[]{
					new Book("title1", "author1", 10000, new GregorianCalendar(), 0.1),
					new Book("title2", "author2", 20000, new GregorianCalendar(), 0.2),
					new Book("title3", "author3", 30000, new GregorianCalendar(), 0.3),
					new Book("title4", "author4", 40000, new GregorianCalendar(), 0.4),
					new Book("title5", "author5", 50000, new GregorianCalendar(), 0.5)
				};		
		
		//	2. "books.dat" 파일에 객체 기록 저장함		
		//	3. try with resource 문 사용할 것
		try( ObjectOutputStream objOut = new ObjectOutputStream( new FileOutputStream("books.dat") ) ) {
			// 메모리 -> 파일  :  out, write
			
			// 저장
			for(Book b : books) {
				objOut.writeObject(b);
				System.out.println(b);
			}
			
			//	4. "books.dat 에 저장 완료!" 출력
			System.out.println("books.dat 에 저장 완료!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
	
	// + fileRead():void
	public void fileRead(){	
		//	1. Book 객체 배열 선언 : 10개
		Book[] books = new Book[10];
		
		//	4. try with resource 문 사용할 것
		try ( ObjectInputStream objIn = new ObjectInputStream( new FileInputStream("books.dat") ) ) {
			// 메모리 <-  파일  : in, read
			
			for(int i = 0; i < books.length; i++){

				//	2. "books.dat" 파일에서 데이터 읽어서 배열에 저장함
				books[i] = (Book)objIn.readObject();
				
				//	3. 객체 정보를 화면에 출력함
				System.out.println(books[i]);	
			}
			
			//	5. "books.dat 읽기 완료!" 출력
			// System.out.println("books.dat 읽기 완료!");	
			
		} catch (EOFException e) {
			//	5. "books.dat 읽기 완료!" 출력			
			System.out.println("books.dat 읽기 완료!");	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
}
