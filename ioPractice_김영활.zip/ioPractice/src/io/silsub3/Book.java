package io.silsub3;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;

// Book.java - 직렬화 처리함
@SuppressWarnings("serial")
public class Book implements Serializable {
	// Field
	private String title;					//도서명
	private String author;				//저자
	private int price;						//가격
	private Calendar dates;			//출판날짜
	private double discountRate;		//할인율

	//  Constructor
	// + 디폴트 생성자
	public Book(){}
	
	// + 매개변수 있는 생성자
	public Book(String title, String author, int price, Calendar dates, double discountRate) {
		super();
		this.title = title;
		this.author = author;
		this.price = price;
		this.dates = dates;
		this.discountRate = discountRate;
	}	
	
	//* Method
	//+ Setters ans Getters 작성

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Calendar getDates() {
		return dates;
	}

	public void setDates(Calendar dates) {
		this.dates = dates;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	
	// + toString():String	Override
	@Override
	public String toString(){
		//	: 날짜에 포맷 적용함 ("yyyy'년' MM'월' dd'일 출간')
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy'년' MM'월' dd'일 출간'");
		
		// 출력
		return this.title + ", " 
						+ this.author + ", " 
						+ this.price + ", " 
						+ sdf.format(this.dates.getTime()) 
						+ ", " + this.discountRate ;
	}

}
