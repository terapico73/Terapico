package io.silsub3;

public class TestBookManager {

	public static void main(String[] args) {
		// main() 포함
		// 1. BookManager 클래스의 메소드 실행 테스트함
		BookManager ref = new BookManager();
		
		// 메모리에서 파일로 보내기 : out, write
		ref.fileSave();
		System.out.println();

		// 파일에서  메모리로 가져오기 : in, read		
		ref.fileRead();

	}

}
