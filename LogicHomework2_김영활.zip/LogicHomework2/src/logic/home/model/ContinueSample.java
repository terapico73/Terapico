package logic.home.model;

public class ContinueSample {

	public void sumJumpThree() {
		// 1. 1~100까지의 정수 중 3의 배수를 뺀 정수들의 합계 출력하기
		int sum = 0;
		
		for (int i = 1; i < 101; i++) {				
			if (i % 3 == 0) continue;  // 3의 배수 빼기				
			
			// 합계
			sum += i;	
			
			// 출력
			if (i == 100) System.out.print(i + " = "+ sum +"\n");
			else System.out.print(i + " + "); 
		}
		System.out.println("1~100까지의 정수 중 3의 배수를 뺀 정수들의 합계  : "+ sum);
	}

	public void rowColJump() {
		// 2. 3행(라인) 5열(칸)의 행열값 출력하되, 1행 3열부터 1행 5열까지 생략하고 출력하기
		int row = 3, col = 5;
	    
	    for(int i = 1 ; i <= row ; i++) {
	    	for (int j = 1 ; j <= col ; j++) {
	    		
	    		if ( i == 1 &&  j > 2 ) {
	    			// 1행 3열부터 1행 5열까지 생략
	    			System.out.print("     | ");
	    			continue;
	    		} 	
	    			
	    		// 출력
	    		System.out.print(i +""+ j + " | ");
	    		
	    	}
	    	System.out.println();
	    }
	    
	    
	}

}
