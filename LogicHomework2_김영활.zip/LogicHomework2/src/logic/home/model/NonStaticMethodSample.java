package logic.home.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class NonStaticMethodSample {

	Scanner sc = new Scanner(System.in);
	
	public void testScanner() {
		// 1. Scanner 클래스 사용 : 자료형 종류별로 값 입력받아 출력하기
		
		/*
		System.out.print("Boolean 자료형 입력 : ");
		boolean bl = sc.nextBoolean();
		*/
		
		System.out.print("byte 자료형 입력 : ");
		byte bt = sc.nextByte();
		
		System.out.print("short 자료형 입력 : ");
		short st = sc.nextShort();
		
		System.out.print("int 자료형 입력 : ");
		int it = sc.nextInt();
		
		System.out.print("long 자료형 입력 : ");
		long lg = sc.nextLong();
		
		System.out.print("float 자료형 입력 : ");
		float ft = sc.nextFloat();
		
		System.out.print("double 자료형 입력 : ");
		double db = sc.nextDouble();
		
		System.out.print("char 자료형 입력 : ");	
		char ch = sc.next().charAt(0);
		
		// System.out.println("Boolean 자료형 : "+ bl);
		System.out.println("byte 자료형 : " + bt);
		System.out.println("short 자료형 : " + st );
		System.out.println("int 자료형 : " + it);
		System.out.println("long 자료형 : " + lg);
		System.out.println("float 자료형 : " + ft);
		System.out.println("double 자료형 : " + db );
		System.out.println("char 자료형 : " + ch);
		
	}

	public void testDate() {
		// 2. Date 클래스 사용 : 오늘 날짜, 현재 시간 정보 출력하기
		Date today = new Date();

		System.out.println("오늘 날짜, 현재 시간 정보 : " + today);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("오늘 날짜, 현재 시간 정보 : " + dateFormat.format(today));		
	}

	public void testRandom() {
		// 3. Random 클래스 사용 : 정수와 실수에 대한 난수 출력하기

        Random random = new Random();

        System.out.println("정수에 대한 난수 : " + Math.abs(random.nextInt()) ); 
        System.out.println("실수에 대한 난수 : " + random.nextFloat() );   
                
        // random 메소드 사용 : 
        // (int) ( (Math.random()* (최대값 - 최소값 + 1)) + 최소값);            
        System.out.println("5~10 랜덤값 : " + ((int) (Math.random() * (10 - 5 + 1) ) + 5)  );  // 5 ~10
        
	}

}
