package logic.home.model;

import java.util.Scanner;

public class ForSample {

	Scanner sc = new Scanner(System.in);
	
	public void sum1To10() {
		// 1. 1~10까지 정수들의 합계 구하기				
		int sum = 0;
		
		for (int i = 1; i < 11; i++) {			
			// 계산부
			sum += i;
			
			// 출력부
			System.out.print(i);			
			if (i == 10) 	System.out.print(" = ");	
			else 			System.out.print(" + ");
			
		}
		
		System.out.print(sum);
		System.out.println();
	}

	public void sumEven1To100() {
		// 2. 1~100사이의 짝수들의 합게 구하기
		int sum = 0;
		
		for (int i = 0; i < 101; i+=2) {  // 2 씩 증가처리
			
			// 계산부
			sum += i;
			
			// 출력부
			System.out.print(i);			
			if (i == 100) 	System.out.print(" = ");	
			else 				System.out.print(" + ");
			
		}
		
		System.out.print(sum);
		System.out.println();
	}

	public void oneGugudan() {
		// 3. 정수 하나 입력받아, 그 수의 구구단 출력하기
		System.out.println("정수 하나 입력 : " );
		int dan = sc.nextInt();		

		// 구구단 출력
		for(int su = 1; su < 10 ; su++) {
			System.out.println(dan + " * " + su +" = " + (dan * su));
		}

	}

	public void sumMinToMax() {
		// 4. 두 개의 정수를 입력받아, 두 수중 작은 값에서 큰 값까지의 합계 구하기
		//  두 개의 정수를 입력받아, 두 수 중 작은 값을 초기값으로 큰값을 종료값으로 사용
		// 작은 수에서 큰 수까지의 정수들의 합계를 구해서 출력
		// 출력 :  12에서 45까지 정수들의 합계 :  000
		System.out.print("첫번째 정수 : ");
		int num1 = sc.nextInt();				
		System.out.print("두번째 정수 : ");
		int num2 = sc.nextInt();
		
		int sum = 0;

		// 최대값, 최소값 구하기
		int max, min;
		if (num1 > num2) {
			max = num1;
			min = num2;					
		} else {
			max = num2;
			min = num1;			
		}
		
		// 합계 구하기
		for (int i = min ; i <= max ; i++) {
			sum += i;
		}
		System.out.println(min + "에서 "+ max +"까지 정수들의 합계 :  "+ sum);		
	}

	public void printStar() {
		// 5. 줄수와 칸수 입력받아, 입력된 줄수/칸수만큼 별표문자 출력하기
		System.out.print("줄수 입력 : ");
		int hCount = sc.nextInt();
		System.out.print("칸수 입력 : ");
		int wCount = sc.nextInt();
		
		for (int j =1; j<= hCount ; j++) {
			for(int i = 1; i <= wCount ; i++) {
				System.out.print('*');
			}
			System.out.println();
		}	
	}

	public void printNumberStar() {
		// 6. 7줄에 7칸에 별표문자 출력하되, 각 줄에 줄번호와 같은 칸에 숫자 출력하기
		for (int j =1; j<= 7 ; j++) {
			// 줄
			for(int i = 1; i <= 7 ; i++) {
				// 칸
				if (i == j) 	System.out.print(i);		// 줄 칸이 같으면 숫자 출력
				else  			System.out.print('*');	// 별 출력
			}
			System.out.println();
		}
	}

	public void printTriangleStar() {
		// 7. 줄수를 입력받아, 삼각형 모양으로 별표문자 출력하기(양수:직각삼각형, 음수:역삼각형)
		System.out.print("정수 하나 입력 : ");
		int num = sc.nextInt();		
		
		if (num > 0) {
			
			// 양수일때
			for (int line = 1; line <= num ; line++) {
				for(int i=1 ; i <= line ; i++) {
					// 칸수가 줄수보다 작거나 같을때 까지 별
					System.out.print("*");
				}
				System.out.println();
			}
			
		} else if (num < 0) {			
			// 음수일때
			num *= -1;  // num1 = num1 * -1

			for (int line = 1 ; line <= num ; line++) {
				
				for(int i= 1; i <= num ; i++) {
					// 칸수와 줄수 관계 따른 조건
					if (i < line) 	System.out.print(" ");	
						// 칸수가 줄수보다 작으면 공백.
					else 			System.out.print("*");
						// 칸수가 줄수와 같거다 커지면 별.
				}				
				System.out.println();
			}		
			
		} else {		
			// 0일때	
			System.out.println("출력기능이 없습니다.");
		}	
	}

	public void guguDan() {
		// 8. 구구단 2단부터 9단까지 출력하기
		
		for (int dan = 2; dan < 10 ; dan++) {
			for(int su = 1; su < 10 ; su++) {
				System.out.println(dan + " * " + su +" = " + (dan * su));
			}
			System.out.println("------------");
		}		
	}

}
