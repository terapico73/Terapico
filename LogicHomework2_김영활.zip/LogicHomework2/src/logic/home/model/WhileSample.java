package logic.home.model;

import java.util.Random;
import java.util.Scanner;

public class WhileSample {

	Scanner sc = new Scanner(System.in);
	
	public void printUniCode() {
		// 1. 문자 하나 입력받아, 그 문자의 유니코드 출력 반복('0' 입력되면 반복종료)
		
		char inputText;
		
		while (true) {
			 System.out.print("문자 입력 : ");
			 inputText = sc.next().charAt(0);
			 
			// 0입력되면 종료
			if ( inputText == '0' ) break;
			 
			// 출력
			System.out.println("유니코드 : " + (int)inputText);			 
		}
		
		/*
		 	방법 2
			System.out.print("문자 입력 : ");
			
			char inputText;
			
			while ( ( inputText = sc.next().charAt(0) ) != '0' ) {
			
				// 출력
				System.out.println("유니코드 : " + (int)inputText);
				
				// 입력
				System.out.print("문자 입력 : ");
			}
		*/	
		
		System.out.println("프로그램 종료");			

		 
	}

	public void sum1To100() {
		// 2. 1~100까지 정수들의 합계 출력하기(while 문으로 작성)
		int sum = 0;
		int i = 1;
		
		while (i < 101) {			
			// 계산
			sum += i;

			// 증감			
			i++;
		}
		
		// 출력
		System.out.print(sum);
		System.out.println();
	}

	public void numberGame() {
		// 3. 1~100사이의 임의의 정수를 발생시켜, 숫자 알아맞추기
		
		// 랜던값 추출 및 저장
		Random rn  = new Random();
	    int r = rn.nextInt(100);
	    
	    int no = -1;
	    int count = 0;
	    
	    // 맞출때까지
	    while (true) {
	    	System.out.print(" 1~ 100 사이의 추정되는 숫자를 입력하세요. : ");
	    	no = sc.nextInt();
	    	
	    	// 시도 횟수 증가
	    	count ++;    	
	    	
	    	if ( r > no) 	{
	    		System.out.println("입력한 숫자보다 높은 숫자입니다. ");
	    	}
	    	else if ( r < no) 	{
	    		System.out.println("입력한 숫자보다 낮은 숫자입니다.  ");
	    	}
	    	else 	{
	    		System.out.println("맞습니다.  ("+ count +"회 시도) ");  
	    		break;
	    	}	    	
	    }	    
	}

	public void countCharacter() {
		// 4. 문자열을 입력받아, 글자 갯수 알아내어 출력하기
		System.out.print("문자열 입력 : ");
		String inputTextString = sc.next();		
		
		// 문자열 길이
		int count = inputTextString.length(); 	
		
		// 결과 출력
		System.out.println("글자 갯수 : "+ count +" 개");		
	}

	public void countInChar() {
		// 5. 문자열값과 문자 하나를 입력받아, 문자열에 문자가 몇 개 있는지 확인하기
		System.out.print("문자열 입력 : ");
		String inputTextString = sc.next();		
		
		int count = inputTextString.length(); 	// 문자열 길이
		
		int notCharCount = 0; 	// 영문자외 문자열 카운트
		
		// 영문자외 문자열 수 구하기
		for (int i = 0; i < count; i++) {			
			
			if ( (inputTextString.charAt(i) < 'a' || inputTextString.charAt(i) > 'z') && (inputTextString.charAt(i) < 'A' || inputTextString.charAt(i) > 'Z')	) {
				notCharCount++;
			}
			
			/*  기타 방법 1 -  조건에 반대 조건 ! 붙여서 처리 
				if ( ! ((inputTextString.charAt(i) >= 'a' && inputTextString.charAt(i) <= 'z') || (inputTextString.charAt(i) >= 'A' && inputTextString.charAt(i) <= 'Z')	) ) {)
			*/
			
			/* 	기타 방법 2 - Character.isAlphabetic() 메소드 활용
				char c = inputTextString.charAt(i);
				if (!Character.isAlphabetic(c)) {}
			*/
			
		}
		
		if ( notCharCount > 0 ) {
			// 영문자외 문자가 있으면 실행
			System.out.println("영문자가 아닙니다. ");
			// System.out.println("영문자가 아닌 글자 수는 " + notCharCount + "개입니다 .");
		} else {
			// 영문자외 문자가 없으면 실행			
			System.out.print("문자 입력 : ");
			char ch = sc.next().charAt(0);
			
			int matCharCount = 0; 	// 매칭카운트
			
			// 문자열 한개씩 비교
			for (int i = 0; i < count; i++) {				
					// 	문자가 같으면 증가
					if ( ch == inputTextString.charAt(i) ) matCharCount++;	
			}		
			
			// 결과 출력
			System.out.println("포함된 갯수 : "+ matCharCount +" 개");
		
		}	// if 문 종료
		
	}

}
