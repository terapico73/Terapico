package logic.home.model;

public class BreakSample {
	public void sumBreak() {
		// 1. 1~100까지 정수들의 합계 출력하기(break문 사용)		
		int i = 1, sum = 0;
		
		do {
			sum += i;
			i++;
			
			// 100 초과하면 종료
			if (i > 100) break;
			
		} while (true);
		
		System.out.println("1~100까지 정수들의 합계 : "+ sum);
	}

	public void guguDanBreak() {
		// 2. 구구단 1단~9단까지 출력하되, * 5 계산에서 반복문 빠지기(break 이름 사용)
		for (int dan = 1; dan <= 9 ; dan++) {
			for (int su = 1; su <= 9 ; su++) {
				System.out.println( dan + " * " + su + " = " + (dan * su));
			}
			System.out.println("-----------");
			
			// 5단에서 종료
			if (dan == 5) break;
		}	
	}

}
