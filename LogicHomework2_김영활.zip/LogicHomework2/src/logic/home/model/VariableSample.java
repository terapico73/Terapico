package logic.home.model;

import java.util.Scanner;

public class VariableSample {
	
	// 클래스 안에 생성자가 존재하지 않으면, java virtual machine (jvm) 이 컴파일 할때
	// 기본생성자를 (public 클래스명(){}) 클래스에 자동 추가하면서 컴파일함
	
	// 1. 필드로 Scanner 클래스에 대한 변수 선언/생성 
	Scanner sc = new Scanner(System.in);
	
	// 1. 내 신상정보 변수에 담아 출력하기
	public void myProfile(){		
		// 본인소개문구를 콘솔에 출력하는 문구를 완성해 보시오.
		String name = "김영활";
		char  gender = '남';
		int age = 50;
		String addr = "경기도 구리시";		
		
		System.out.println("이름 : "+ name);  
		System.out.println("성별 : "+ gender +"자 ");
		System.out.println("나이 : "+ age);
		System.out.println("거주지 : "+ addr);
	}
	
	// 2. 사원정보를 키보드로 입력받아 출력하기
	public void empInformation(){
		System.out.print("사번 : ");
		String empID = sc.next();
		System.out.print("이름 : ");
		String empName = sc.next();
		System.out.print("주민등록번호 : ");
		String empNo = sc.next();
		System.out.print("소속부서 : ");
		String deptName = sc.next();
		System.out.print("직급 : ");
		String jopTitle = sc.next();
		System.out.print("급여 : ");
		int salary = sc.nextInt();
		System.out.print("보너스포인트 (소수점아래 둘째짜리까지) : ");
		double bPoint = sc.nextDouble();
		
		System.out.println("직원정보 : ["+ empID +", "+ empName +", "+ empNo +", "+ deptName 
				+", "+ jopTitle +", "+ salary +", "+ bPoint +"]");
		
	}
	
	// 3. 기본 자료형 변수의 초기값 확인하기
	public void defaultValue() {
		// 변수 초기화 :  변수 방에 만들면서 바로 초기값을 기록시킴
		// 초기값 : 변수 방에 첫번째로 기록되는 값
		// 문법 : 자료형 변수명 =  초기값;
		
		boolean flag = true;
		char ch = '\u0000';
		byte bnum = 0;
		short snum = 0;
		int inum = 0;			
		long lnum = 0L;	
		float fnum = 0.0f;
		double dnum = 0.0;
		
		System.out.println("flag 초기값 : "+ flag);
		System.out.println("char 초기값 : "+ ch);
		System.out.println("byte 초기값 : "+ bnum);
		System.out.println("short 초기값 : "+ snum);
		System.out.println("int 초기값 : "+ inum);
		System.out.println("long 초기값 : "+ lnum);
		System.out.println("float 초기값 : "+ fnum);		
		System.out.println("double 초기값 : "+ dnum);
		
		// return;		
	}

}
