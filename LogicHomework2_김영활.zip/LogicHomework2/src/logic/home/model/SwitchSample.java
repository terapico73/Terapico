package logic.home.model;

import java.util.Scanner;

public class SwitchSample {

	Scanner sc = new Scanner(System.in);
	
	public void calculator() {
		// 1. 두 개의 정수와 한 개의 연산문자를 입력받아 계산한 결과 확인하기
		/*
	 	입력 예 : 
	 		첫번째 정수 : 25
	 		두번째 정수 : 7
	 		연산문자 (+, -, *, /, %) : +
	 	출력 예 :
	 		25 + 7 = 32
	 	입력된 연산문자에 따라 계산식과 결과가 출력
		*/
		
		System.out.print("첫번째 정수 : ");
		int num1 = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int num2 = sc.nextInt();
		System.out.print("연산문자 (+, -, *, /, %) : ");
		char inputCase = sc.next().charAt(0);
		
		int result  = 0 ; // 지역변수는 반드시 초기화 해야 함
		
		// 기호에 따라 연산
		switch (inputCase) {
			case '+' : result = num1 + num2; 	break;
			case '-' : result = num1 - num2;  	break;
			case '*' : result = num1 * num2;  	break;
			case '/' : result = num1 / num2;  	break;
			case '%' : result = num1 % num2;	break;
			default : inputCase = '?';
		}
		
		// 출력
		if (inputCase == '?') {
			System.out.println("연산기호 오류");
		} else {
			System.out.println(num1 + " "+ inputCase+" "+ num2 +" = "+ result );
		}
	}

	public void fruitPrice() {
		// 2. 과일이름을 문자열로 입력받아, 그 과일의 가격 출력하기
		/*
	  	과일명(String) 과 수량(Int) 을 입력받아, 가격(Price)을 계산해서 출력
	  	과일에 따라 한개의 가격 저장용 변수 준시 : int price;
	  	사과 1200
	  	배 2500
	  	포도 5000
	  	오렌지 500
	  	키위 350
	  	그외 다른 과일은 0		  	
	  	총구매가격 : price * 수량
	  	(출력)
	  		사과 한 개 의 가격은 1200원
	  		구매수량은 5개
	  		총 구매가격 : 6000원
		*/
		
		System.out.print("과일명 : ");
		String name = sc.next();
		System.out.print("수량 : ");
		int count = sc.nextInt();
		
		int price = 0;		
		
		// 선택에 따라 가격정
		switch (name) {
			case "사과" : 		price = 1200; 		break;   
			case "배" : 			price = 2500; 	break;
			case "포도" : 		price = 5000; 	break;
			case "오렌지" : 	price = 500; 		break;
			case "키위" : 		price = 350; 		break;
			default : 			name = "미판매";
		}
		
		// 판매여부에 따라 출력
		if (name == "미판매") {
			System.out.println("판매되지 않는 과일입니다.");
		} else {
			System.out.println(name + " 한 개 의 가격은 "+ price +"원");
			System.out.println("구매수량은 "+ count +"개");
			System.out.println("총 구매가격 : "+ (price * count) +"원");
		}
	}

}
