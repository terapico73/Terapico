package logic.home.model;

import java.util.Scanner;

public class IfSample {

	// 1. 필드로 Scanner 클래스에 대한 변수 선언/생성 
	Scanner sc = new Scanner(System.in);
	
	public void maxNumber() {
		// 1. 두 개의 정수를 입력받아, 두 수중 큰 값 출력하기
		System.out.print("첫번째 정수 : ");
		int num1 = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int num2 = sc.nextInt();
		
		int max;
		
		// 큰값 구하기
		if (num1 > num2) 	max = num1;
		else						max = num2;
		
		// 출력
		System.out.println("큰값은 " + max + " 입니다");
	}

	public void minNumber() {
		// 2. 두 개의 정수를 입력받아, 두 수중 작은 값 출력하기
		System.out.print("첫번째 정수 : ");
		int num1 = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int num2 = sc.nextInt();
		
		int min;
		
		// 작은값 구하기
		if (num1 > num2) 	min = num2;
		else						min = num1;
			
		// 출력
		System.out.println("작은값은 " + min + " 입니다");
	}

	public void threeMaxMin() {
		// 3. 세 개의 정수를 입력받아, 세 수중 가장 큰수와 가장 작은수 출력하기	

		System.out.print("첫번째 정수 : ");
		int num1 = sc.nextInt();
		System.out.print("두번째 정수 : ");
		int num2 = sc.nextInt();
		System.out.print("세번째 정수 : ");
		int num3 = sc.nextInt();
		
		int max, min;

		// 가장 큰 값 구하기
		if (num1 > num2 && num1 > num3) 	max = num1;
		else if ( num2 > num3) 						max = num2;
		else 													max = num3;
		
		// 작은 값 구하기
		if (num1 < num2 && num1 < num3) 	min = num1;
		else if ( num2 < num3) 						min = num2;
		else 													min = num3;
		
		// 출력
		System.out.println("최대값는 "+ max + ", 최소값은 "+ min +"이다. ");
		
	}

	public void checkEven() {
		// 4. 한 개의 정수를 입력받아, 짝수인지 홀수인지 출력하기
		System.out.print("정수 입력 : ");
		int num = sc.nextInt();
		
		// 조건에 따라 출력
		if (num % 2 == 0) {
			System.out.println(num + "은 짝수!");
		} else {
			System.out.println(num + "홀수!");
		}
	}

	public void isPassFail() {
		// 5. 국,영,수 세 과목의 점수를 입력받아, 합격/불합격 확인하기
		
		// 국어, 영어, 수학 점수를 입력받아, 총점과 평균을 계산하고
		// 각 과목별 점수가 각각 40점 이상이고, 평균이 60점 이상이면 "합격"
		// 아니면, "불합격" 출력
				
		System.out.print("국어 : ");
		int kor = sc.nextInt();
		System.out.print("영어 : ");
		int end = sc.nextInt();
		System.out.print("수학 : ");
		int mat = sc.nextInt();
		
		// 계산
		int total = kor + end + mat;
		double avg = total / 3 ;
		
		// 조건에 따라 합격, 불합격
		if ( kor >= 40 && end >= 40 && mat >= 40 && avg >= 60) {
			System.out.println("합격");
		} else {
			System.out.println("불합격");		
		}	
	}

	public void scoreGrade() {
		// 6. 점수를 입력받아, 학점 확인하기
		
		/*
		키보드로 점수(score, int) 입력받아, 점수에 대한 등급(grade, char)을 부여, 출력.
		단, 점수는 반드시 0 이상의 값이어야 함.
		점수 >= 90 > 'A',
		점수 >= 80 > 'B',
		점수 >= 70 > 'C',
		점수 >= 60 > 'D',
		점수 < 60 > 'F',		대입함
		점수와 등급을 출력 처리함.
		점수가 0미만이면 "잘못 입력하였습니다." 출력			  
		*/
		
		System.out.print("점수 : ");
		int score = sc.nextInt();
		
		char grade;
		
		if (score >= 0) {
			// 점수가 0이상에만 등급
			if (score >= 90) 			grade = 'A';
			else if (score >= 80) 	grade = 'B';
			else if (score >= 70) 	grade = 'C';
			else if (score >= 60) 	grade = 'D';
			else 							grade = 'F';			
			
			System.out.println("등급 : "+ grade);
		} else {
			System.out.println("잘못 입력하였습니다.");
		}	
		
	}

	public void checkPlusMinusZero() {
		// 7. 한 개의 정수를 입력받아, 양수인지 0인지 음수인지 확인하기
		System.out.print("정수 하나 입력 : ");
		int no = sc.nextInt();
		
		if ( no > 0) {
			//  양수
			System.out.println("양수입니다.");
		} else if (no == 0) {
			//  0
			System.out.println("0입니다.");
		} else {
			// 음수
			System.out.println("음수입니다.");
		}
	}

	public void whatCaracter() {
		// 8. 문자 하나를 입력받아, 영어대문자인지 소문자인지 숫자문자인지 기타문자인지 확인하기
		System.out.print("문자 하나 입력 : ");
		char ch = sc.next().charAt(0);
		
		// 영어대문자
		if (ch >= 'A' && ch <= 'Z') {
			System.out.println("대문자입니다.");
		} else if (ch >= 'a' && ch <= 'z') {
		// 영어소문자
			System.out.println("소문자입니다.");
		} else if (ch >= '0' && ch <= '9') {
		// 숫자
			System.out.println("숫자입니다.");
		} else {
		// 기타문자
			System.out.println("기타문자입니다.");
		}
		
	}

}
