package logic.home.model;

import java.text.DecimalFormat;
import java.util.Scanner;

public class DoWhileSample {

	Scanner sc = new Scanner(System.in);	
	DecimalFormat df = new DecimalFormat("###,###");
	
	public void addDashToken() {
		// 1. 문자열값 입력받아, 문자 사이에 '-' 끼워넣어 출력하기
		System.out.print("첫번째 문자열 : ");
		String inputText1 = sc.next();
		System.out.print("두번째 문자열 : ");
		String inputText2 = sc.next();
		
		System.out.println(inputText1 + "-" + inputText2);
		
	}

	public void burgerKingMenu() {
		// 2. 버거킹 메뉴 주문 테스트
		/*
		*** 메뉴를 선택하세요 ***
	
		햄버거 ***************
		1. 불고기버거		3500원
		2. 치킨버거		3200원
		추가 ****************
		3. 감자튀김		1000원
		4. 치즈스틱		400원
		5. 샐러드			2000원
		음료수 ***************
		6. 콜라				700원
		7. 에이드			1200원
		8. 커피				1000원
		********************
		메뉴 선택 : 1
		불고기버거를 선택하셨습니다.
		수량은 ? 3
		3개 주문하셨습니다.	//계산 처리됨
	
		추가 주문하시겠습니까?(y/n) : y 입력시 메뉴화면 반복실행됨
		 */
		
		int totalPrice = 0;
		int price = 0;
		String printResult = "";	// 주문서 출력
		
		do {			
			System.out.println("*** 메뉴를 선택하세요 ***");
			System.out.println();
			System.out.println("햄버거 *********************");
			System.out.println("1. 불고기버거	3500원");
			System.out.println("2. 치킨버거		3200원");
			System.out.println("추가 ***********************");
			System.out.println("3. 감자튀김		1000원");
			System.out.println("4. 치즈스틱		400원");
			System.out.println("5. 샐러드		2000원");
			System.out.println("음료수 *********************");
			System.out.println("6. 콜라		700원");
			System.out.println("7. 에이드		1200원");
			System.out.println("8. 커피		1000원");
			System.out.println("****************************");
			System.out.print("메뉴 선택 : ");
			int num = sc.nextInt();
			System.out.println();
			
			// 입력된 번호별 처리, 
			//  1. 선택메뉴 출력, 2. 주문서 출력, 3. 메뉴별 개당 금액 정의
			switch (num) {
				case 1 : System.out.println("불고기버거를 선택하셨습니다."); 	printResult += "불고기버거 : ";	price = 3500;	break;
				case 2 : System.out.println("치킨버거를 선택하셨습니다.");		printResult += "치킨버거 : ";		price = 3200;	break;
				case 3 : System.out.println("감자튀김를 선택하셨습니다.");		printResult += "감자튀김 : ";		price = 1000;	break;
				case 4 : System.out.println("치즈스틱를 선택하셨습니다.");		printResult += "치즈스틱 : ";		price = 400;		break;
				case 5 : System.out.println("샐러드를 선택하셨습니다.");		printResult += "샐러드 : ";		price = 2000;	break;
				case 6 : System.out.println("콜라를 선택하셨습니다.");			printResult += "콜라 : ";			price = 700;		break;
				case 7 : System.out.println("에이드를 선택하셨습니다.");		printResult += "에이드 : ";		price = 1200;	break;
				case 8 : System.out.println("커피를 선택하셨습니다.");			printResult += "커피 : ";			price = 1000;	break;
				default :
			}
			
			// 수량 입력
			System.out.print("수량은 ? ");
			int count = sc.nextInt();
			
			System.out.println(count + "개 주문하셨습니다.");			
			System.out.println();
			
			printResult += count + "개 - "+ (price * count) + "원" ;	// 주문서 출력부	
			totalPrice += price * count;   		// 주문메뉴 금액 계산 및 합산금액 저장
			
			// 추가 주문 선택
			System.out.print("추가 주문하시겠습니까?(y/n) : ");
			char continueYN = sc.next().charAt(0);			
			System.out.println();
			
			if (continueYN == 'n') break;		// 추가 진행
			
			printResult += " \n";	// 주문서 출력부
			
		} while (true);		
	
		System.out.println("* 주문하신 정보는 다음과 같습니다. *");
		System.out.println("-----------------------------------------------");		
		System.out.println(printResult);		// 주문서 출력부
		System.out.println("-----------------------------------------------");
		System.out.println("총 가격 : "+ df.format(totalPrice) +"원");		
	
	}

	public void isStringAlphabet() {
		// 3. 문자열 입력받아, "모든 글자 영문자다"/"영문자 아니다." 출력하기		
		System.out.print("문자열 입력 : ");
		String inputText = sc.next();
		
		int stringCount = inputText.length();
		int i = 0;
		int engCount = 0;
		
		do {
			// 영문자 판독
			if (Character.isAlphabetic(inputText.charAt(i))) engCount++;
			
			// 증감
			i++;				
		} while (i<stringCount);
		
		//영문 문자수와 입력된 글자수가 비교
		if (engCount == stringCount)	System.out.println("모든 글자 영문자다");
		else 	System.out.println("모든 글자가 영문자 아니다.");
	}

}
