package logic.home.view;

import java.util.Scanner;

import logic.home.model.BreakSample;
import logic.home.model.ContinueSample;
import logic.home.model.DoWhileSample;
import logic.home.model.ForSample;
import logic.home.model.IfSample;
import logic.home.model.NonStaticMethodSample;
import logic.home.model.PrimitiveTypeSample;
import logic.home.model.StaticMethodSample;
import logic.home.model.SwitchSample;
import logic.home.model.VariableSample;
import logic.home.model.WhileSample;

public class Menu {
	// 맴버변수 (Fields, 필드)
	// 작성방법 :  접근제한자 [예약어] 자료형 변수명 [=초기값];
	//					접근제한자 : public, private, protected, default
	//					자료형 : static
	private static Scanner sc = new Scanner(System.in);
	
	// 맴버생성자 (Constructors, 컨스트럭터) : 클래스가 가진 모든 맴버가  static 이면 필요없음.
	
	// 맴버함수 (Method, 메소드)
	public static void mainMenu() {
		
		do {
			System.out.println("***** 프로그래밍 기본 기능 테스트 프로그램 ***** \r\n"
					+ "1. 변수 테스트 \r\n"
					+ "2. 기본 자료형 테스트 \r\n"
					+ "3. if문 테스트	\r\n"
					+ "4. switch문 테스트	\r\n"
					+ "5. for문 테스트	\r\n"
					+ "6. while문 테스트	\r\n"
					+ "7. do~while문 테스트	\r\n"
					+ "8. break문 테스트	\r\n"
					+ "9. continue문 테스트	\r\n"
					+ "10. static 메소드 사용 테스트	\r\n"
					+ "11. non-static 메소드 사용 테스트	\r\n"
					+ "12. 프로그램 종료 ");
			System.out.print("메뉴 번호 입력 : ");
			int no = sc.nextInt();		// int num = new Scanner(System.in).nextInt();
			
			switch (no) {
				case 1 : subVarMenu() ; 						break;
				case 2 : subPTypeMenu(); 					break;
				case 3 : subIfMenu(); 							break;
				case 4 : subSwitchMenu(); 					break;
				case 5 : subForMenu(); 						break;
				case 6 : subWhileMenu(); 					break;
				case 7 : subDoWhileMenu(); 					break;
				case 8 : subBreakMenu(); 						break;
				case 9 : subContinueMenu(); 				break;
				case 10 : subStaticMethodMenu(); 			break;
				case 11 : subNonStaticMethodMenu(); 	break;
				case 12 : 
					// 프로그램종료
					System.out.print("정말로 종료하시겠습니까? (예:y/아니오:n) : ") ;					
					if (sc.next().toUpperCase().charAt(0) == 'Y') 	return; 
					System.out.println();
					
					break; 							
				default: //잘못된 번호가 입력되었을 때 메뉴 다시 출력되게 함
					System.out.println("입력 오류!! 다시 입력하세요.");
					System.out.println();
			} // switch 종료
		} while (true);	// do~while 종료		
		
	}	
	
	// 과제 5
	public static void subVarMenu(){
		// 1. VariableSample 클래스 지역변수로 선언/생성 
		// 클래스가 제공하는 메소드를 사용하려며, 먼저 클래스에 대한 객체 생성부터 해야 함
		// 작성방법 : 클레스명 레퍼런스 변수 = new		
		VariableSample ref = new VariableSample();
		
		// 2. 변수테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** 변수 테스트 부메뉴 *** \r\n"
					+ "1. 내 신상정보 변수에 담아 출력하기 \r\n"
					+ "2. 사원정보를 키보드로 입력받아 출력하기 \r\n"
					+ "3. 기본 자료형 변수의 초기값 확인하기 \r\n"
					+ "4. 이전 메뉴로 가기 ");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
	
			// 3. 선택된 메뉴 번호에 따라 VariableSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no) {
				case 1 : ref.myProfile(); 			break;
				case 2 : ref.empInformation(); 	break;
				case 3 : ref.defaultValue();		 break;
				case 4 : System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default : // 잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("입력 오류!! 다시 입력하세요. ");
			} // swich 종료
		} while (true);	// do~while 종료	

	}
	
	//  과제6 
	public static void subPTypeMenu(){
		// 1. PrimitiveTypeSample 클래스 지역변수로 선언/생성
		PrimitiveTypeSample ref = new PrimitiveTypeSample();
		
		// 2. 기본자료형에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** 기본자료형 테스트 부메뉴 ***");
			System.out.println("1. 기본자료형 메모리 할당크기 확인하기");
			System.out.println("2. 기본자료형 값의 최소값, 최대값 출력하기");
			System.out.println("3. 기본자료형 비트갯수 확인하기");
			System.out.println("4. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 :  ");	 
			int no = sc.nextInt();
			
			// 3. 선택된 메뉴 번호에 따라 PrimitiveTypeSample 클래스의 메소드 실행시킴 	: switch 문 사용
			switch(no)	{
			case 1:	ref.typeSize(); 			break;
			case 2:	ref.minMaxValue(); 		break;
			case 3:	ref.bitSize(); 				break;
			case 4:	System.out.println("메인 메뉴로 돌아갑니다. \n");
				return;	//이전 메뉴로 되돌아감.
			default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
				System.out.println("입력 오류!! 다시 입력하세요. ");			
			} 	 	
		} while (true);
	}
	
	//  과제7 
	public static void subIfMenu(){
		// 1. IfSample 클래스 지역변수로 선언/생성
		IfSample ref = new IfSample();
		
		// 2. if문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {		
			System.out.println("\n*** if문 테스트 부메뉴 ***");
			System.out.println("1. 두 개의 정수를 입력받아, 두 수중 큰 값 출력하기");
			System.out.println("2. 두 개의 정수를 입력받아, 두 수중 작은 값 출력하기");
			System.out.println("3. 세 개의 정수를 입력받아, 세 수중 가장 큰수와 가장 작은수 출력하기");
			System.out.println("4. 한 개의 정수를 입력받아, 짝수인지 홀수인지 출력하기");
			System.out.println("5. 국,영,수 세 과목의 점수를 입력받아, 합격/불합격 확인하기");
			System.out.println("6. 점수를 입력받아, 학점 확인하기");
			System.out.println("7. 한 개의 정수를 입력받아, 양수인지 0인지 음수인지 확인하기");
			System.out.println("8. 문자 하나를 입력받아, 영어대문자인지 소문자인지 숫자문자인지 기타문자인지 확인하기");
			System.out.println("9. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");			
			int no = sc.nextInt();	
			
			// 3. 선택된 메뉴 번호에 따라 IfSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no) {
				case 1:	ref.maxNumber(); 			break;
				case 2:	ref.minNumber(); 			break;
				case 3:	ref.threeMaxMin(); 			break;
				case 4:	ref.checkEven(); 			break;
				case 5:	ref.isPassFail(); 				break;
				case 6:	ref.scoreGrade(); 			break;
				case 7:	ref.checkPlusMinusZero(); break;
				case 8:	ref.whatCaracter(); 			break;
				case 9:	System.out.println("메인 메뉴로 돌아갑니다.  \n");
					return;	//이전 메뉴로 되돌아감.
				default:	//잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("입력 오류!! 다시 입력하세요. ");
			}
			
		} while (true);			
		 
	}
	
	// 과제 8
	public static void subSwitchMenu(){
		// 1. SwitchSample 클래스 지역변수로 선언/생성
		SwitchSample ref = new SwitchSample();
		
		// 2. switch문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함		
		do {
			System.out.println("\n*** switch문 테스트 부메뉴 ***");
			System.out.println("1. 두 개의 정수와 한 개의 연산문자를 입력받아 계산한 결과 확인하기");
			System.out.println("2. 과일이름을 문자열로 입력받아, 그 과일의 가격 출력하기");
			System.out.println("3. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
			
			// 3. 선택된 메뉴 번호에 따라 SwitchSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no)
			{
			case 1:	ref.calculator(); 	break;
			case 2:	ref.fruitPrice(); 	break;
			case 3:	System.out.println("메인 메뉴로 돌아갑니다. \n");
				return;	//이전 메뉴로 되돌아감.
			default:	//잘못된 값 입력시 메뉴 다시 출력되게 처리
				System.out.println("입력 오류!! 다시 입력하세요. ");
			}
		} while (true);
	}
	
	// 과제 9
	public static void subForMenu()	{
		// 1. ForSample 클래스 지역변수로 선언/생성
		ForSample ref =  new ForSample();
		
		// 2. for문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** for문 테스트 부메뉴 ***");
			System.out.println("1. 1~10까지 정수들의 합계 구하기");
			System.out.println("2. 1~100사이의 짝수들의 합게 구하기");
			System.out.println("3. 정수 하나 입력받아, 그 수의 구구단 출력하기");
			System.out.println("4. 두 개의 정수를 입력받아, 두 수중 작은 값에서 큰 값까지의 합계 구하기");
			System.out.println("5. 줄수와 칸수 입력받아, 입력된 줄수/칸수만큼 별표문자 출력하기");
			System.out.println("6. 7줄에 7칸에 별표문자 출력하되, 각 줄에 줄번호와 같은 칸에 숫자 출력하기");
			System.out.println("7. 줄수를 입력받아, 삼각형 모양으로 별표문자 출력하기(양수:직각삼각형, 음수:역삼각형)");
			System.out.println("8. 구구단 2단부터 9단까지 출력하기");
			System.out.println("9. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
				
			// 3. 선택된 메뉴 번호에 따라 ref.메소드 실행시킴 : switch 문 사용
			switch(no)
			{
				case 1:	ref.sum1To10(); 		break;
				case 2:	ref.sumEven1To100(); 	break;
				case 3:	ref.oneGugudan(); 		break;
				case 4:	ref.sumMinToMax(); 	break;
				case 5:	ref.printStar(); 			break;
				case 6:	ref.printNumberStar(); break;
				case 7:	ref.printTriangleStar(); 	break;
				case 8:	ref.guguDan(); 			break;
				case 9:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	//잘못된 값 입력시 메뉴 다시 출력되게 처리
			}
			
		} while (true) ;
	}
	
	// 과제 10
	public static void subWhileMenu(){
		// 1. WhileSample 클래스 지역변수로 선언/생성
		WhileSample ref = new WhileSample();
		// 2. while문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** while문 테스트 부메뉴 ***");
			System.out.println("1. 문자 하나 입력받아, 그 문자의 유니코드 출력 반복('0' 입력되면 반복종료)");
			System.out.println("2. 1~100까지 정수들의 합계 출력하기(while 문으로 작성)");
			System.out.println("3. 1~100사이의 임의의 정수를 발생시켜, 숫자 알아맞추기");
			System.out.println("4. 문자열을 입력받아, 글자 갯수 알아내어 출력하기");
			System.out.println("5. 문자열값과 문자 하나를 입력받아, 문자열에 문자가 몇 개 있는지 확인하기");
			System.out.println("6. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
				
			// 3. 선택된 메뉴 번호에 따라 WhileSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no){
				case 1:	ref.printUniCode(); break;
				case 2:	ref.sum1To100(); break;
				case 3:	ref.numberGame(); break;
				case 4:	ref.countCharacter(); break;
				case 5:	ref.countInChar(); break;
				case 6:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("번호 입력 오류!!");
			}
			
			
		} while (true) ;
	}
	
	// 과제 11
	public static void subDoWhileMenu(){
		// 1. DoWhileSample 클래스 지역변수로 선언/생성
		DoWhileSample ref = new DoWhileSample();
		
		// 2. do~while문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			
			System.out.println("\n*** do~while문 테스트 부메뉴 ***");
			System.out.println("1. 문자열값 입력받아, 문자 사이에 '-' 끼워넣어 출력하기");
			System.out.println("2. 버거킹 메뉴 주문 테스트");
			System.out.println("3. 문자열 입력받아, \"모든 글자 영문자다\"/ \"영문자 아니다.\" 출력하기");
			System.out.println("4. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
			
			// 3. 선택된 메뉴 번호에 따라 DoWhileSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no) {
				case 1:	ref.addDashToken(); 	break;
				case 2:	ref.burgerKingMenu(); break;
				case 3:	ref.isStringAlphabet(); 	break;
				case 4:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("번호 입력 오류!");
			} 
		} while (true);
	}

	// 과제 12
	public static void subBreakMenu(){
		// 1. BreakSample 클래스 지역변수로 선언/생성
		BreakSample ref = new BreakSample();
		
		// 2. break문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** break문 테스트 부메뉴 ***");
			System.out.println("1. 1~100까지 정수들의 합계 출력하기(break문 사용)");
			System.out.println("2. 구구단 1단~9단까지 출력하되, * 5 계산에서 반복문 빠지기(break 이름 사용)");
			System.out.println("3. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
			
			// 3. 선택된 메뉴 번호에 따라 BreakSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no){
				case 1:	ref.sumBreak() ; break;
				case 2:	ref.guguDanBreak() ; break;
				case 3:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	//잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("번호 입력 오류 !");
			}
		} while (true);
	}

	// 과제 13
	public static void subContinueMenu(){
		// 1. ContinueSample 클래스 지역변수로 선언/생성
		ContinueSample ref = new ContinueSample();
		
		// 2. continue문 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			
			System.out.println("\n*** continue문 테스트 부메뉴 ***");
			System.out.println("1. 1~100까지의 정수 중 3의 배수를 뺀 정수들의 합계 출력하기");
			System.out.println("2. 3행 5열의 행열값 출력하되, 1행 3열부터 1행 5열까지 생략하고 출력하기");
			System.out.println("3. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
				
			// 3. 선택된 메뉴 번호에 따라 ContinueSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no)
			{
			case 1:	ref.sumJumpThree(); break;
			case 2:	ref.rowColJump(); break;
			case 3:	System.out.println("메인 메뉴로 돌아갑니다. \n");
				return;	//이전 메뉴로 되돌아감.
			default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
				System.out.println("번호 입력 오류 !");
			}
		} while (true);
	}
	
	// 과제 14
	public static void subStaticMethodMenu(){
		// 1. StaticMethodSample 클래스 지역변수로 선언/생성
		StaticMethodSample ref = new StaticMethodSample();
		
		// 2. static 메소드 사용 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			
			System.out.println("\n*** static 메소드 사용 테스트 부메뉴 ***");
			System.out.println("1. Math 클래스의 랜덤값 구하는 메소드 : 1~45사이의 임의의 정수 출력");
			System.out.println("2. Math 클래스의 실수값에 대한 절대값 구하는 메소드 : -12.77 절대값 출력하기");
			System.out.println("3. Math 클래스의 두 정수중 큰값 구하는 메소드 : 120, 54 중 큰값 출력하기");
			System.out.println("4. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
				
			// 3. 선택된 메뉴 번호에 따라 StaticMethodSample 클래스의 메소드 실행시킴	: switch 문 사용
			
			switch(no)
			{
				case 1:	ref.testMathRandom(); break;
				case 2:	ref.testMathAbs(); break;
				case 3:	ref.testMathMax(); break;
				case 4:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("번호 입력 오류");
			}
			
		}  while (true); 
	}
	
	// 과제 15
	public static void subNonStaticMethodMenu(){
		// 1. NonStaticMethodSample 클래스 지역변수로 선언/생성
		NonStaticMethodSample ref = new NonStaticMethodSample();		
		
		// 2. non-static 메소드 사용 테스트에 대한 메뉴 출력함 : do~while로 반복 출력 처리함
		do {
			System.out.println("\n*** non-static 메소드 사용 테스트 부메뉴 ***");
			System.out.println("1. Scanner 클래스 사용 : 자료형 종류별로 값 입력받아 출력하기");
			System.out.println("2. Date 클래스 사용 : 오늘 날짜, 현재 시간 정보 출력하기");
			System.out.println("3. Random 클래스 사용 : 정수와 실수에 대한 난수 출력하기");
			System.out.println("4. 이전 메뉴로 가기");
			System.out.print("메뉴 선택 : ");
			int no = sc.nextInt();
			
			// 3. 선택된 메뉴 번호에 따라 NonStaticMethodSample 클래스의 메소드 실행시킴 : switch 문 사용
			switch(no) {
				case 1:	ref.testScanner(); break;
				case 2:	ref.testDate(); break;
				case 3:	ref.testRandom(); break;
				case 4:	System.out.println("메인 메뉴로 돌아갑니다. \n");
					return;	//이전 메뉴로 되돌아감.
				default:	// 잘못된 값 입력시 메뉴 다시 출력되게 처리
					System.out.println("번호 입력 오류 !");
			}			
			
		} while (true);
	}	
	
}
