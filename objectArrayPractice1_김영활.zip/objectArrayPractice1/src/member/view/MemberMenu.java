package member.view;

import java.util.Scanner;
import member.model.dao.MemberManager;

public class MemberMenu {
	// Field
	private Scanner sc;								//키보드 입력용 객체 생성 초기화함
	private MemberManager mManager; 	// 회원관리 클래스 객체 생성 초기화함

	{
		sc = new Scanner(System.in);
	}	

	// 디폴트 생성자 작성
	public MemberMenu() {}
	
	// 메소드 작성
	// 0. 회원 관리 프로그램 - 메인
	public void mainMenu(){
		mManager = new MemberManager();

		//		MemberManager 클래스의 public static final SIZE(상수필드)값 출력시킴
		//		최대 등록 가능한 회원 수는 10 명입니다.
		System.out.println("최대 등록 가능한 회원 수는 "+ mManager.SIZE +" 명입니다. ");		
		
		// 메뉴는 반복 출력되게 함		
		do {		
			//		//MemberManager 클래스의 memberCount 필드의 값을 리턴받아 출력
			//		현재 등록된 회원수는 5명 입니다.
			System.out.println("현재 등록된 회원수는 "+ mManager.getMemberCount() +" 입니다. \n");
			
			System.out.println(" ***** 회원 관리 프로그램 ***** \n");
			System.out.println(" 1. 새 회원 등록 ");		// 객체배열사용
			System.out.println(" 2. 회원 조회 ");			// equals 사용
			System.out.println(" 3. 회원 정보 수정 ");	// setter사용
			System.out.println(" 4. 회원 정보 정렬 ");	// compareto 사용
			System.out.println(" 5. 회원 삭제 ");	
			System.out.println(" 6. 모두 출력 ");
			System.out.println(" 9. 끝내기 ");
			System.out.print(" 메뉴 선택 : ");
			int no = sc.nextInt();
			
			//		- 입력된 번호에 따라 MemberManager 클래스의 메소드가 실행되게 함
			//		- 조회, 수정, 정렬 메뉴는 각각 부메뉴에 대한 메소드를 실행되게 함			
			switch (no) {
				case 1 : mManager.memberInput(); break;	
				case 2 : searchMenu(); break;	
				case 3 : modifyMenu(); break;
				case 4 : sortMenu(); break;
				case 5 : mManager.deleteMember();  break;
				case 6 : mManager.printAllMember(); break;				
				case 9 : 
					System.out.print("정말로 끝내시겠습니까? (y/n) : ");
					if ( sc.next().toUpperCase().charAt(0) == 'Y' ) {
						return;
					}
				default : 
					System.err.println("번호입력 오류 !!");
			}
		} while (true) ;
		
	}
	
	// 0-2. 회원 조회	
	public void searchMenu(){
		
		do {
			// System.out.println("현재 등록된 회원수는 "+ mManager.getMemberCount() +" 입니다. \n");
			
			System.out.println("\n ***** 회원 정보 검색 메뉴 ***** \n");
			System.out.println(" 1. 아이디로 검색 ");
			System.out.println(" 2. 이름으로 검색 ");
			System.out.println(" 3. 이메일로 검색 ");
			System.out.println(" 9. 이전 메뉴로 가기 ");
			System.out.print(" 메뉴 선택 :  ");
			int no = sc.nextInt();
			int index = -1;
			// 번호에 따라 MemberManager 클래스의 메소드 실행함		
			
			switch (no) {
				case 1 : 
					// 1번 선택시 >> 키보드로 아이디를 입력받아, 메소드로 아이디를 전달함
					// 검색한 회원의 정보가 존재하면, 그 회원의 배열인덱스를 리턴함
					// 존재하지 않으면 -1을 리턴함
					
					System.out.print(" 아이디 입력 :  ");
					String id = sc.next();			
					index = mManager.searchMemberId(id);			
					
					break;
				case 2 : 
					//	2번 선택시 >> 키보드로 이름을 입력받아, 메소드로 아이디를 전달함
					//	검색한 회원의 정보가 존재하면, 그 회원의 배열인덱스를 리턴함
					//	존재하지 않으면 -1을 리턴함
					
					System.out.print(" 이름 입력 :  ");
					String name = sc.next();			
					index = mManager.searchMemberName(name);
					
					break;
				case 3 : 
					// 3번 선택시 >> 키보드로 이메일을 입력받아, 메소드로 아이디를 전달함
					// 검색한 회원의 정보가 존재하면, 그 회원의 배열인덱스를 리턴함
					// 존재하지 않으면 -1을 리턴함
					
					System.out.print(" 메일 입력 :  ");
					String email = sc.next();			
					index = mManager.searchMemberEmail(email);
					
					break;
				case 9 : 
					// 9번 선택시 >> "메인 메뉴로 화면 이동합니다." 출력하고, 리턴함
					System.out.println("메인 메뉴로 화면 이동합니다. \n");
					
					return;
				default :					
					System.err.println("번호입력 오류 !!");
			}	

			// 리턴받은 인덱스 위치가 -1보다 큰값이면 그 위치의 회원 정보를 출력함
			// >> MemberManager 클래스의 printMember(index) 실행
			// 리턴받은 값이 -1이면, "회원정보가 존재하지 않습니다." 출력함
			if ( index > -1 ) {
				mManager.printMember(index);					
			} else {
				System.err.println(" 회원정보가 존재하지 않습니다. ");
			}

		} while (true) ;
		
	}
	
	// 0-4. 회원 정보 정렬
	public void sortMenu(){
		do {
			System.out.println("\n ***** 회원 정보 정렬 출력 메뉴 ***** \n");
			System.out.println(" 1. 아이디 오름차순 정렬 출력 ");
			System.out.println(" 2. 아이디 내림차순 정렬 출력 ");
			System.out.println(" 3. 나이 오름차순 정렬 출력 ");
			System.out.println(" 4. 나이 내림차순 정렬 출력 ");
			System.out.println(" 5. 성별 내림차순 정렬 출력(남여순) ");
			System.out.println(" 9. 이전 메뉴로 가기 ");
			System.out.print(" 메뉴 선택 :  ");
			int no = sc.nextInt();
			
			switch(no) {
				case 1 : mManager.sortIDAsc(); break;
				case 2 : mManager.sortIDDes();break;
				case 3 : mManager.sortAgeAsc();break;
				case 4 : mManager.sortAgeDes();break;
				case 5 : mManager.sortGenderDes();break;
				case 9 : 
					// 9번 선택시 >> "메인 메뉴로 화면 이동합니다." 출력하고, 리턴함
					System.out.println("메인 메뉴로 화면 이동합니다. \n");					
					return;
				default :
					System.err.println("번호입력 오류 !!");
			}
	
		} while (true) ;
		
	}
	
	// 0-3. 회원 정보 수정
	public void modifyMenu(){
		
		do {
			System.out.println("\n ***** 회원 정보 수정 메뉴 ***** \n");
			System.out.println(" 1. 암호 변경 ");
			System.out.println(" 2. 이메일 변경 ");
			System.out.println(" 3. 나이 변경 ");
			System.out.println(" 9. 이전 메뉴로 가기	 ");	
			System.out.print(" 메뉴 선택 :  ");
			int no = sc.nextInt();
			
			String id;
			int index = -1;
			switch(no) {
				case 1 : 
					// - 1번 선택시 >> 변경할 회원의 아이디 : 입력받음
					System.out.print(" 변경할 회원의 아이디 : ");
					id = sc.next();
					
					// MemberManager 클래스의 검색메소드 실행함 >>
					index = mManager.searchMemberId(id);
					
					if (index != -1) {
						// 리턴받은 인덱스로 회원의 정보를 출력함
						mManager.printMember(index);	
						
						// 변경할 암호 : 입력받음
						System.out.print(" 변경할 암호 : ");
						String pwd = sc.next();
						
					    // Member 클래스의 setPassword(암호) 실행
						mManager.findMember(index).setPassword(pwd);
						
						// "회원의 정보가 변경되었습니다." 출력
						System.out.println("회원의 정보가 변경되었습니다.");
						mManager.printMember(index);

					} else {
						// 단, 검색메소드의 리턴값이 -1아닌 경우에만 실행되게 함
						System.err.println("회원정보가 없습니다. ");
					}
					
					break;
				case 2 : 
					//	- 2번 선택시 >> 변경할 회원의 아이디 : 입력받음
					System.out.print(" 변경할 회원의 아이디 : ");
					id = sc.next();
					
					// MemberManager 클래스의 검색메소드 실행함 >>
					index = mManager.searchMemberId(id);
					
					if (index != -1) {					
						// 리턴받은 인덱스로 회원의 정보를 출력함
						mManager.printMember(index);	
						
						// 변경할 이메일주소 : 입력받음
						System.out.print(" 변경할 이메일주소 : ");
						String email = sc.next();	
						
						// Member 클래스의 setEmail(이메일) 실행
						mManager.findMember(index).setEmail(email);
						
						// "회원의 정보가 변경되었습니다." 출력
						System.out.println("회원의 정보가 변경되었습니다.");	
						mManager.printMember(index);

					}  else {
						// 단, 검색메소드의 리턴값이 -1아닌 경우에만 실행되게 함
						System.err.println("회원정보가 없습니다. ");
					}
					
					break;
				case 3 : 
					// - 3번 선택시 >> 변경할 회원의 아이디 : 입력받음
					System.out.print(" 변경할 회원의 아이디 : ");
					id = sc.next();
					
					// MemberManager 클래스의 검색메소드 실행함 >>
					index = mManager.searchMemberId(id);
					
					if (index != -1) {							
						// 리턴받은 인덱스로 회원의 정보를 출력함
						mManager.printMember(index);	
						
						// 변경할 나이 : 입력받음
						System.out.print(" 변경할 나이 : ");
						int age = sc.nextInt();		
						
						// Member 클래스의 setAge(나이) 실행
						mManager.findMember(index).setAge(age);
						
						// "회원의 정보가 변경되었습니다." 출력
						System.out.println("회원의 정보가 변경되었습니다.");
						mManager.printMember(index);
							
					}  else {
						// 단, 검색메소드의 리턴값이 -1아닌 경우에만 실행되게 함
						System.err.println("회원정보가 없습니다. ");
					}
			
					break;
				case 9 : 
					// 9번 선택시 >> "메인 메뉴로 화면 이동합니다." 출력하고, 리턴함
					System.out.println("메인 메뉴로 화면 이동합니다. \n");					
					return;
				default :
					System.err.println("번호입력 오류 !!");
			}			
		} while (true);
	}
}
