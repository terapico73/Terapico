package member.controller;

import member.view.MemberMenu;

/**
 * 회원관리 프로그램 2024.01.13
 */
public class Main {

	// 회원관리 프로그램 구동
	public static void main(String[] args) {

		MemberMenu mMenu = new MemberMenu();	
		mMenu.mainMenu();

		System.out.println("회원관리 프로그램을 종료합니다.");
	}
}
