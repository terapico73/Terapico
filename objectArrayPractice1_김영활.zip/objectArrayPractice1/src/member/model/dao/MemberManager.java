package member.model.dao;

import java.util.Scanner;

import member.model.dto.Member;

public class MemberManager {
	
	//	 - Field 구성
	public static int SIZE = 10;	// 배열 크기 지정용 상수
	private int memberCount;	// 현재 등록된 객체 수 카운트용
	private Member[] mar; 		// SIZE 사용 배열 초기화 할당함
	private Member[] marCopy;	// 배열 카피
	Scanner sc;							// 키보드 입력용 객체 생성 초기화함
	
	//	 - 초기화블럭 작성 : 테스트에 사용할 샘플 객체 5개 생성함
	{
		sc = new Scanner(System.in);
		
		mar = new Member[SIZE];
		marCopy = new Member[SIZE];
		
		mar[0] = new Member("e4im12*3", "이승만", "pwkkk34!",  "kim123@naver.com", 'M', 35);
		mar[1] = new Member("aksrose71#", "박정희", "aksrose71#", "aksrose71@daum.net", 'F', 81);			  
		mar[2] = new Member("dksrose72#", "최규하", "tksrose72#", "tksrose72@daum.net", 'M', 44);
		mar[3] = new Member("bksrose73#", "전두환", "zksrose73#", "zksrose73@daum.net", 'F', 13);			  
		mar[4] = new Member("cksrose77#", "김대중", "sksrose74#", "sksrose74@daum.net", 'M', 50);

		memberCount = 5;
	}

	//	- 디폴트 생성자 작성
	public MemberManager() {}
	
	public MemberManager(int memberCount, Member[] mar, Scanner sc) {
		super();
		this.memberCount = memberCount;
		this.mar = mar;
		this.sc = sc;
	}

	//	메소드 작성
	//	1. memberCount 필드에 대한 getter 작성
	public int getMemberCount() {
		return memberCount;
	}
	
	// 2. 새 회원 정보 입력용 메소드 작성
	// 0-1. 새 회원 등록
	public void memberInput(){
	
		// System.out.println("현재 등록된 회원수는 "+ memberCount +" 입니다. \n");
				
		//	키보드로 새 회원의 정보를 입력받아, 배열에 기록함
		//	Member 클래스의 setter 사용함		
		System.out.print("아이디 : ");
		String id = sc.next();
		
		System.out.print("이름 : ");
		String name =  sc.next();
		
		System.out.print("패스워드 : ");
		String password = sc.next();
		
		System.out.print("이메일주소 : ");
		String Email = sc.next();
		
		System.out.print("성별 : ");		
		char Gender = sc.next().charAt(0);
		
		System.out.print("나이 : ");		
		int age = sc.nextInt();

		mar[memberCount] = new Member(id, name, password, Email, Gender, age);
		
		//	마지막에 memberCount 1증가시킴	
		memberCount++;
	}
	
	// 3. 배열에서 회원 정보 삭제용 메소드 작성
	// 0-5. 회원 삭제
	public void deleteMember(){
		// 삭제할 회원의 아이디를 입력받음
		System.out.print(" 삭제할 회원의 아이디 : ");
		String id = sc.next();
		
		// 리턴받은 인덱스에 대한 회원정보 출력함
		int idx = searchMemberId(id);
		if (idx != -1) {
			printMember(idx);
			
			// 정말로 삭제하시겠습니까? (y/n) : 출력
			System.out.println(" 정말로 삭제하시겠습니까? (y/n) : ");
			char c = sc.next().toUpperCase().charAt(0);
			
			if ( c == 'Y') {			
	
				// 입력값이 대소문자 상관없이 'Y' 이면, 해당 인덱스의 레퍼런스를 null로 처리함
				mar[idx] = null;
				
				// 단, 검색한 회원의 인덱스가 0 또는 중간 위치일 경우에는 
				//      지울 위치 뒤의 주소들을 하나씩 앞으로 옮김
				// 		마지막 인덱스일 경우에만 null 처리함			
				for (int i = idx ; i < memberCount-1 ; i++) {
					mar[i] = mar[i+1];
				}
				// 삭제 후 memberCount 1 줄임		
				memberCount-- ;
			} 
		} else {
			System.err.println(" 회원정보가 존재하지 않습니다. ");
		}

	}
	
	//	4. 배열에 기록된 현재 회원 전체 정보 출력용 메소드 작성	
	// 0-6. 모두 출력
	public void printAllMember(){
		//	Member 클래스의 memberInfo() 사용 출력처리함
		for (int i = 0 ; i < memberCount ; i++) {
			System.out.println(mar[i].memberInfo());
		}
	}
	
	//	5. 아이디를 이용한 회원정보 검색용 메소드 작성
	// 0-2-1. 아이디로 검색
	public int searchMemberId(String id){
		//	전달받은 아이디와 일치하는 회원이 있는지 찾음
		//	회원이 존재하면, 반복을 종료하고 해당 인덱스를 
		//	존재하지 않으면 -1을 리턴 처리함	
		
		int idx = -1;		
		for(int i = 0 ; i < memberCount ; i++){
			//System.out.println(mar[i].getId());
			if (mar[i].getId().equals(id)) idx = i; 
		}		
		return idx;
	}
	
	// 6. 이름을 이용한 회원정보 검색용 메소드 작성
	// 0-2-2. 이름으로 검색
	public int searchMemberName(String name){
		//	전달받은 이름과 일치하는 회원이 있는지 찾음
		//	회원이 존재하면, 반복을 종료하고 해당 인덱스를 
		//	존재하지 않으면 -1을 리턴 처리함
		
		int idx = -1;		
		for(int i = 0 ; i < memberCount ; i++){
			//System.out.println(mar[i].getName());
			if (mar[i].getName().equals(name)) idx = i; 
		}		
		return idx;
	}
	
	//	7. 이메일주소를 이용한 회원정보 검색용 메소드 작성
	// 0-2-3. 이메일로 검색
	public int searchMemberEmail(String email){
		//	전달받은 이메일과 일치하는 회원이 있는지 찾음
		//	회원이 존재하면, 반복을 종료하고 해당 인덱스를 
		//	존재하지 않으면 -1을 리턴 처리함		
		int idx = -1;		
		for(int i = 0 ; i < memberCount ; i++){
			if (mar[i].getEmail().equals(email)) idx = i; 
		}		
		return idx;
	}
	
	//	8. 한 사람의 회원 정보 출력용 메소드 작성
	public void printMember(int index){
		//  전달받은 인덱스에 대한 회원정보 출력함
		//  >> Member 클래스의 memberInfo() 메소드 사용함
		System.out.println(" 회원정보 : " + mar[index].memberInfo() );
	}	  
	
	// 9. 아이디순 오름차순 정렬하는 메소드 작성
	// 0-4-1. 아이디 오름차순 정렬 출력
	public void sortIDAsc(){
		//	현재 등록된 회원에 대한 배열을 복사함
		System.arraycopy(mar, 0, marCopy, 0, marCopy.length);
		
		//	복사본에 대해 Select Sort 방식의 오름차순 정렬 처리		
		for(int i = 0; i < memberCount; i++) {
			for(int j = 0; j < memberCount; j++) {
				if( marCopy[i].getId().compareTo(marCopy[j].getId()) < 0) {
					// 변경
					swap(marCopy, i, j);
				}
			}
		}	
		
		//	정렬이 끝나면 각 레퍼런스별 memberInfo()를 사용 출력함
		for(int i = 0; i < memberCount; i++) {		
			System.out.println(marCopy[i].memberInfo());
		}		
	}
	
	// swap
	public void swap(Member[] a, int i, int  j){
		Member[] Temp = new Member[SIZE];	
		
		Temp[i] = a[i]; 
		a[i] = a[j];
		a[j] =Temp[i];
	}
	
	// 10. 아이디순 내림차순 정렬하는 메소드 작성
	// 0-4-2. 아이디 내림차순 정렬 출력	
	public void sortIDDes(){
		//	현재 등록된 회원에 대한 배열을 복사함
		System.arraycopy(mar, 0, marCopy, 0, marCopy.length);
		
		for(int i = 0; i < memberCount; i++) {
			for(int j = 0 ; j < memberCount ; j++) {
				// 비교 				
				if( marCopy[i].getId().compareTo(marCopy[j].getId()) > 0) {
					// 변경
					swap(marCopy, i, j);
				} 
			}	
		}	
		
		//	정렬이 끝나면 각 레퍼런스별 memberInfo()를 사용 출력함
		for(int i = 0; i < memberCount; i++) {		
			System.out.println(marCopy[i].memberInfo());
		}
	}
	
	// 11. 나이순 오름차순 정렬하는 메소드 작성
	// 0-4-3. 나이순 오름차순  정렬 출력	
	public void sortAgeAsc(){		
		//	현재 등록된 회원에 대한 배열을 복사함
		System.arraycopy(mar, 0, marCopy, 0, marCopy.length);
		
		//  복사본에 대해 Select Sort 방식의 오름차순 정렬 처리	
		for(int i = 0; i < memberCount; i++) {
			for(int j = 0 ; j < memberCount ; j++) {
				// 비교 
				if(marCopy[i].getAge() < marCopy[j].getAge()) {
					// 변경
					swap(marCopy, i, j);
				} 
			}	
		}			
		//  정렬이 끝나면 각 레퍼런스별 memberInfo()를 사용 출력함
		for(int i = 0; i < memberCount; i++) {		
			System.out.println(marCopy[i].memberInfo());
		}		
	}
	
	// 12. 나이순 내림차순 정렬하는 메소드 작성
	// 0-4-4. 나이순 내림차순  정렬 출력	
	public void sortAgeDes(){
		// 현재 등록된 회원에 대한 배열을 복사함
		System.arraycopy(mar, 0, marCopy, 0, marCopy.length);

		// 복사본에 대해 Select Sort 방식의 내림차순 정렬 처리	
		for(int i = 0; i < memberCount; i++) {			
			for(int j = 0 ; j < memberCount ; j++) {				
				// 비교				
				if(marCopy[i].getAge() > marCopy[j].getAge()) {					
					// 변경
					swap(marCopy, i, j);
				} 
			}	
		}		
		
		// 정렬이 끝나면 각 레퍼런스별 memberInfo()를 사용 출력함
		for(int i = 0; i < memberCount; i++) {		
			System.out.println(marCopy[i].memberInfo());
		}	
	}
	
	// 13. 성별순 내림차순 정렬하는 메소드 작성
	// 0-4-5. 성별순 내림차순  정렬 출력		
	public void sortGenderDes(){
		//  현재 등록된 회원에 대한 배열을 복사함
		System.arraycopy(mar, 0, marCopy, 0, marCopy.length);	
		
		//	복사본에 대해 Select Sort 방식의 오름차순 정렬 처리			
		for(int i = 0; i < memberCount; i++) {			
			for(int j = 0 ; j < memberCount ; j++) {				
				// 비교				
				if(marCopy[i].getGender() > marCopy[j].getGender()) {					
					// 변경
					swap(marCopy, i, j);
				} 
			}	
		}	
		
		//	정렬이 끝나면 각 레퍼런스별 memberInfo()를 사용 출력함
		for(int i = 0; i < memberCount; i++) {		
			System.out.println(marCopy[i].memberInfo());
		}
		
	}
	
	//	14. MemberMenu 클래스에서 회원정보 수정 기능에서 사용함
	//	인덱스를 전달받아, 인덱스 위치에 기록된 객체의 주소를 리턴하는 메소드 작성
	public Member findMember(int index){
		//	배열 인덱스에 기록된 주소를 리턴함
		return mar[index];
	}

}
