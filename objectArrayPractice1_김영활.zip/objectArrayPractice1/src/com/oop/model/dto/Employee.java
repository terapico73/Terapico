package com.oop.model.dto;

public class Employee {
	/*
	 * Field 작성 : 캡슐화 반드시 적용함
	 */
	private int empNo; 		// 사번 
	private String empName;	// 이름
	private String dept; 		// 소속부서
	private String job; 			// 직급
	private int age;				// 나이
	private char gender;		// 성별
	private int salary;			// 급여
	private double bonusPoint; // 보너스포인트
	private String phone;		// 핸드폰
	private String address;	// 주소
	
	/*
	 * Constructors (생성자) 작성 
	 */
	// 	디폴트 생성자와 매개변수 있는 생성자 추가함
	// 매개변수 있는 생성자 2개 작성함
	public Employee() {} 		// 디폴드 생성자	

	// * 사번, 이름, 나이, 성별, 핸드폰, 주소 초기화 생성자
	public Employee(int empNo, String empName, int age, char gender, String phone, String address) {
		this.empNo = empNo;
		this.empName = empName;
		this.age = age;
		this.gender = gender;
		this.phone = phone;
		this.address = address;

		return;		
	}
	
	// * 모든 필드를 초기화하는 생성자
	public Employee(int empNo, String empName, String dept,  String job, int age
												, char gender, int salary, double bonusPoint	, String phone, String address) {
		this.empNo = empNo;
		this.empName = empName;
		this.dept = dept;
		this.job = job;
		this.age = age;
		this.gender = gender;
		this.salary = salary;
		this.bonusPoint = bonusPoint;
		this.phone = phone;
		this.address = address;
		
		return;		
	}
	
	// 각 필드에 대한 Setter & Getter 메소드 추가함
	// Setter
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}	
	public void setSalary(int salary) {
		this.salary = salary;
	}	
	public void setBonusPoint(double bonusPoint) {
		this.bonusPoint = bonusPoint;
	}	
	public void setPhone(String phone) {
		this.phone = phone;
	}	
	public void setAddress(String address) {
		this.address = address;
	}

	//	Getter
	public int getEmpNo () {
		return this.empNo;
	}
	public String getEmpName() {
		return this.empName;
	}
	public String getDept() {
		return this.dept;
	}
	public String getJob() {
		return this.job;
	}
	public int getAge() {
		return this.age;
	}
	public char getGender() {
		return this.gender;
	}
	public int getSalary() {
		return this.salary;
	}
	public double getBonusPoint() {
		return this.bonusPoint;
	}	
	public String getPhone() {
		return this.phone;
	}	
	public String getAddress() {
		return this.address;
	}	
	
	// 모든 필드값을 하나의 문장(문자열합치기)으로 만들어 리턴하는 메소드 추가함
	public String empInformation() {
		String result = empNo + " " + empName + " " + dept + " " + job + " " + age + " " + gender + " " + salary + " " 
				+ bonusPoint + " " + phone + " " + address;		
		return result; 
	}
}
