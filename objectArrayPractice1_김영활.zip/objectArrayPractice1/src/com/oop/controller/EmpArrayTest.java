package com.oop.controller;

import com.oop.model.dto.Employee;

/**
 * 사원관리 프로그램 실행 파일
 */
public class EmpArrayTest {

	public static void main(String[] args) {
		
		// 1. 3개의 생성자를 사용하여 3개의 객체를 배열로 생성함
		// 2. empInformation() 메소드를 사용하여, 3객체의 정보를 출력함
		Employee[] ear = new Employee[3];
		
		// ear[0] : 0, null, null, null, 0, □, 0, 0.0, null, null
		ear[0] = new Employee();
		// System.out.println("ear[0] : "+ ear[0].empInformation());
	
		// ear[1] : 201503, 박길동, null, null, 29, M, 0, 0.0, 010-1234-5678, 경기도 의정부시
		ear[1] = new Employee(201503, "박길동", 29,  'M',  "010-1234-5678", "경기도 의정부시");
		// System.out.println("ear[1] : "+ ear[1].empInformation());
		
		// ear[2] : 201004, 김철수, 개발부, 과장, 34, M, 4500000, 0.15, 010-2143-9876, 서울시 노원구 노원동 123
		ear[2] = new Employee(201004, "김철수", "개발부", "과장", 34, 'M', 4500000, 0.15, "010-2143-9876", "서울시 노원구 노원동 123");
		// System.out.println("ear[2] : "+ ear[2].empInformation());		
		
		for (int i = 0 ; i < ear.length ; i++) {
			System.out.println("ear["+ i +"] : "+ ear[i].empInformation());
		}
		
		System.out.println("-------------------------------------------------------");	
		
		// 3. 3개의 객체중 값이 없는 필드에 각각 값을 입력해 넣음
		// ear[0] : 201305, 이영희, 총무부, 대리, 28, F, 3750000, 0.1, 010-9512-7534, 경기도 동두천
		ear[0].setEmpNo(201305);
		ear[0].setEmpName("이영희");
		ear[0].setDept("총무부");
		ear[0].setJob("대리");	
		ear[0].setAge(28);
		ear[0].setGender('F');
		ear[0].setSalary(3750000);
		ear[0].setBonusPoint(0.1);
		ear[0].setPhone("010-9512-7534");
		ear[0].setAddress("경기도 동두천");
		// System.out.println("ear[0] : "+ ear[0].empInformation());
		
		// ear[1] : 201503, 박길동, null, null, 29, M, 0, 0.0, 010-1234-5678, 경기도 의정부시
		// ear[1] : 201503, 박길동, 기획부, 사원, 29, M, 2900000, 0.05, 010-1234-5678, 경기도 의정부시	
		ear[1].setDept("기획부");
		ear[1].setJob("사원");
		ear[1].setSalary(2900000);
		ear[1].setBonusPoint(0.05);
		// System.out.println("ear[1] : "+ ear[1].empInformation());
		
		for (int i = 0 ; i < ear.length ; i++) {
			System.out.println("ear["+ i +"] : "+ ear[i].empInformation());
		}
		
		System.out.println("-------------------------------------------------------");	
		
		// 4. 직원 각각의 보너스가 적용된 1년 연봉을 계산하여 출력함
		//		연봉 = (급여 + (급여 * 보너스포인트)) * 12 ;
		int totalSalary0 =  (ear[0].getSalary() + (int)(ear[0].getSalary()  * ear[0].getBonusPoint() )) * 12 ;
		int totalSalary1 =  (ear[1].getSalary() + (int)(ear[1].getSalary()  * ear[1].getBonusPoint() )) * 12 ;
		int totalSalary2 =  (ear[2].getSalary() + (int)(ear[2].getSalary()  * ear[2].getBonusPoint() )) * 12 ;	
		// 5. 3직원의 1년 연봉의 평균을 구하여 출력함
		System.out.println(ear[0].getEmpName() + "의 연봉 : " + totalSalary0 );
		System.out.println(ear[1].getEmpName() + "의 연봉 : " + totalSalary1 );
		System.out.println(ear[2].getEmpName() + "의 연봉 : " + totalSalary2 );
		
		System.out.println("-------------------------------------------------------");	
		
		int avg = (totalSalary0 + totalSalary1 + totalSalary2) / 3;
		System.out.println("직원들의 연봉의 평균 : " + avg );
		
		System.out.println("-------------------------------------------------------");			

		
	}

}
